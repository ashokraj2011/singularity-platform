# Context Fabric — PostgreSQL + Agent UID Edition

This build includes the latest architecture decisions:

- PostgreSQL as the system of record
- JSONB for flexible payloads
- pgvector extension enabled for future semantic memory
- `agent_uid = sha256(capability_id + ":" + agent_id)`
- no `agent_instance_id` required in the API
- external Agent Registry / Learning Service integration point
- Context Fabric fetches runtime profile and injects learning profile, but does not own durable agent learning
- LLM Call Handoff mode, where Context Fabric prepares the LLM call and the client executes it with its own key
- server-executed LLM mode still works

## Run

```bash
cp .env.example .env
docker compose up --build
```

Open:

```text
http://localhost:8000/docs
```

## Main request

```bash
curl -s http://localhost:8000/chat/respond \
  -H "Content-Type: application/json" \
  -d '{
    "session_id": "demo-001",
    "capability_id": "context-fabric",
    "agent_id": "developer-agent",
    "message": "Explain where token saving happens.",
    "provider": "mock",
    "model": "mock-fast",
    "context_policy": {
      "optimization_mode": "medium",
      "compare_with_raw": true,
      "max_context_tokens": 16000
    }
  }' | jq
```

The response includes:

```text
agent_key = context-fabric:developer-agent
agent_uid = sha256(agent_key)
optimization.raw_input_tokens
optimization.optimized_input_tokens
optimization.tokens_saved
```

## LLM Call Handoff

```bash
curl -s http://localhost:8000/chat/respond \
  -H "Content-Type: application/json" \
  -d '{
    "session_id": "handoff-001",
    "capability_id": "context-fabric",
    "agent_id": "developer-agent",
    "message": "Prepare the OpenAI call but do not execute it.",
    "provider": "openai",
    "model": "gpt-4.1-mini",
    "llm_execution": {"mode": "return_call"},
    "context_policy": {
      "optimization_mode": "medium",
      "compare_with_raw": true
    }
  }' | jq
```

Context Fabric returns a `prepared_call`. The client executes it with its own API key and posts the result back:

```text
POST /client-llm-calls/{client_model_call_id}/complete
```

## External Agent Registry / Learning Service

Set this in `.env`:

```env
AGENT_LEARNING_SERVICE_URL=http://agent-learning-service:8040
```

Context Fabric will call:

```text
GET /runtime-profile?capability_id=...&agent_id=...
POST /learning-candidates
```

The runtime profile can return:

```json
{
  "capability_id": "context-fabric",
  "agent_id": "developer-agent",
  "agent_key": "context-fabric:developer-agent",
  "agent_uid": "...",
  "system_prompt": "You are the Developer Agent...",
  "default_provider": "openai",
  "default_model": "gpt-4.1-mini",
  "default_context_mode": "medium",
  "allowed_tools": ["code.search"],
  "learning_profile": {
    "version": 7,
    "summary_text": "Durable learning for this agent..."
  }
}
```

Context Fabric stores the runtime profile hash and learning profile version on every context package for audit.

## PostgreSQL tables

Key schemas/tables:

- `memory.conversation_messages`
- `memory.context_summaries`
- `memory.memory_items`
- `context.context_packages`
- `llm.model_calls`
- `llm.client_llm_calls`
- `metrics.token_savings_runs`

The database init file is:

```text
database/init.sql
```

import uuid
import requests

BASE_URL = "http://localhost:8000"
MEMORY_URL = "http://localhost:8002"


def test_return_call_prepares_llm_call_and_callback_stores_response():
    session_id = f"handoff-test-{uuid.uuid4()}"
    agent_id = "developer-agent"

    # Seed some history so token optimization has context to work with.
    for i in range(4):
        r = requests.post(
            f"{MEMORY_URL}/memory/messages",
            json={
                "session_id": session_id,
                "agent_id": agent_id,
                "role": "user" if i % 2 == 0 else "assistant",
                "content": f"Historical Context Fabric design message {i}. Token savings compare raw and optimized context.",
            },
            timeout=30,
        )
        assert r.status_code == 200, r.text

    r = requests.post(
        f"{BASE_URL}/chat/respond",
        json={
            "session_id": session_id,
            "agent_id": agent_id,
            "message": "Explain where token saving happens.",
            "provider": "openai",
            "model": "gpt-4.1-mini",
            "llm_execution": {"mode": "return_call"},
            "context_policy": {
                "optimization_mode": "medium",
                "compare_with_raw": True,
                "max_context_tokens": 16000,
            },
        },
        timeout=30,
    )
    assert r.status_code == 200, r.text
    data = r.json()
    assert data["status"] == "client_llm_call_required"
    assert data["prepared_call"]["execution_type"] == "http"
    assert data["prepared_call"]["auth"]["value_source"] == "client"
    assert "context_package_id" in data
    assert "client_model_call_id" in data

    complete = requests.post(
        f"{BASE_URL}/client-llm-calls/{data['client_model_call_id']}/complete",
        json={
            "session_id": session_id,
            "agent_id": agent_id,
            "context_package_id": data["context_package_id"],
            "provider": "openai",
            "model": "gpt-4.1-mini",
            "response_text": "The token saving happens in services/context_memory_service/app/context_compiler.py.",
            "usage": {"input_tokens": data["optimization"]["optimized_input_tokens"], "output_tokens": 25},
            "optimization": data["optimization"],
        },
        timeout=30,
    )
    assert complete.status_code == 200, complete.text
    assert complete.json()["status"] == "saved"

    messages = requests.get(f"{BASE_URL}/sessions/{session_id}/messages", timeout=30)
    assert messages.status_code == 200, messages.text
    roles = [m["role"] for m in messages.json()["messages"]]
    assert "assistant" in roles

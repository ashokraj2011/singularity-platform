# LLM Call Handoff

Context Fabric now supports a mode where it compiles optimized context and returns the exact LLM call for the client to execute with client-owned keys or local auth.

## Modes

`llm_execution.mode` supports:

- `server` — Context Fabric calls the LLM through `llm-gateway-service`.
- `return_call` — Context Fabric returns a prepared provider call to the client and does not call the LLM.
- `compile_only` — Context Fabric returns optimized messages only.

## 1. Prepare a client-executed OpenAI call

```bash
curl -s http://localhost:8000/chat/respond \
  -H 'Content-Type: application/json' \
  -d '{
    "session_id":"handoff-demo-001",
    "agent_id":"developer-agent",
    "message":"Explain where token saving happens in Context Fabric.",
    "provider":"openai",
    "model":"gpt-4.1-mini",
    "temperature":0.2,
    "max_output_tokens":1000,
    "llm_execution":{"mode":"return_call"},
    "context_policy":{
      "optimization_mode":"medium",
      "compare_with_raw":true,
      "max_context_tokens":16000
    }
  }' | jq
```

The response contains:

```json
{
  "status": "client_llm_call_required",
  "client_model_call_id": "...",
  "context_package_id": "...",
  "prepared_call": {
    "method": "POST",
    "url": "https://api.openai.com/v1/chat/completions",
    "auth": {
      "type": "bearer",
      "header": "Authorization",
      "value_source": "client"
    },
    "headers": {
      "Content-Type": "application/json"
    },
    "body": {
      "model": "gpt-4.1-mini",
      "messages": [],
      "temperature": 0.2,
      "max_tokens": 1000
    }
  },
  "optimization": {
    "raw_input_tokens": 52000,
    "optimized_input_tokens": 8400,
    "tokens_saved": 43600,
    "percent_saved": 83.84
  }
}
```

Context Fabric never returns a server-side key. The client injects its own key.

## 2. Client executes the prepared call

Example JavaScript:

```js
const prepared = handoffResponse.prepared_call;

const openaiResponse = await fetch(prepared.url, {
  method: prepared.method,
  headers: {
    ...prepared.headers,
    Authorization: `Bearer ${clientOpenAiKey}`
  },
  body: JSON.stringify(prepared.body)
});

const data = await openaiResponse.json();
const text = data.choices[0].message.content;
```

## 3. Client posts result back to Context Fabric

```bash
curl -s http://localhost:8000/client-llm-calls/<client_model_call_id>/complete \
  -H 'Content-Type: application/json' \
  -d '{
    "session_id":"handoff-demo-001",
    "agent_id":"developer-agent",
    "context_package_id":"<context_package_id>",
    "provider":"openai",
    "model":"gpt-4.1-mini",
    "response_text":"The token saving logic is in context_compiler.py...",
    "usage":{
      "input_tokens":8400,
      "output_tokens":700,
      "total_tokens":9100
    },
    "optimization":{
      "mode":"medium",
      "raw_input_tokens":52000,
      "optimized_input_tokens":8400,
      "tokens_saved":43600,
      "percent_saved":83.84,
      "estimated_raw_cost":0.20,
      "estimated_optimized_cost":0.04,
      "estimated_cost_saved":0.16
    }
  }' | jq
```

Context Fabric will store the client-executed LLM response as an assistant message, trigger summarization when thresholds are met, and record token-savings metrics.

## 4. Compile only

```bash
curl -s http://localhost:8000/chat/respond \
  -H 'Content-Type: application/json' \
  -d '{
    "session_id":"compile-only-demo",
    "agent_id":"developer-agent",
    "message":"Build optimized context only.",
    "llm_execution":{"mode":"compile_only"},
    "context_policy":{"optimization_mode":"medium","compare_with_raw":true}
  }' | jq
```


# Capability + Agent Scope

Context Fabric now treats agents as scoped under a capability.

## Why

`agent_id` is usually a logical role such as `developer-agent` or `architect-agent`. That is not globally unique because many capabilities can have their own developer agent.

The durable identity is:

```text
capability_id + agent_id + optional agent_instance_id
```

Recommended meanings:

- `capability_id`: the parent capability/application/workflow domain, for example `context-fabric`, `singularityneo`, `brokerage-workflow`, or `customer-intent-model`.
- `agent_id`: logical agent role inside that capability, for example `developer-agent`.
- `agent_instance_id`: optional unique runtime/persona instance when multiple instances of the same logical agent exist.

## Request example

```json
{
  "session_id": "session-001",
  "capability_id": "context-fabric",
  "agent_id": "developer-agent",
  "agent_instance_id": "context-fabric:developer-agent:v1",
  "message": "Explain where token saving happens.",
  "provider": "openai",
  "model": "gpt-4.1-mini",
  "context_policy": {
    "optimization_mode": "medium",
    "compare_with_raw": true,
    "max_context_tokens": 16000
  }
}
```

## Persistence

The following stores now persist capability/agent scoping:

- `conversation_messages`
- `context_summaries`
- `memory_items`
- `context_packages`
- `model_calls`
- `token_savings_runs`

Existing SQLite databases are migrated lazily on startup with `ALTER TABLE ADD COLUMN` if the new columns do not exist.

## Memory retrieval

Context compilation retrieves memory in this order:

1. Capability + logical agent memory
2. Capability + agent instance memory
3. Current session memory
4. Backward-compatible agent-only memory when no capability is provided

This prevents memory from one capability's `developer-agent` from bleeding into another capability's `developer-agent`.

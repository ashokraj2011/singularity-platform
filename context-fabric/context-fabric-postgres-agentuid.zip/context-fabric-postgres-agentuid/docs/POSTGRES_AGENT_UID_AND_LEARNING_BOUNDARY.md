# Agent UID + External Learning Boundary

## Identity

Context Fabric now derives the agent identity from:

```text
agent_key = capability_id + ":" + agent_id
agent_uid = sha256(agent_key)
```

The public API only needs:

```json
{
  "capability_id": "context-fabric",
  "agent_id": "developer-agent"
}
```

## Boundary

Agent Registry / Learning Service owns:

- agent creation
- system prompts
- model/tool policy
- durable versioned learning profiles
- learning approval and rollback

Context Fabric owns:

- raw messages
- rolling session summaries
- context packages
- token savings
- LLM call handoff records
- model-call metrics

## Runtime profile

At context compile time, Context Fabric optionally fetches a runtime profile from the external service and injects:

- system prompt
- learning profile `summary_text`
- default provider/model/context mode

Every context package stores:

- `agent_learning_profile_version`
- `runtime_profile_hash`
- `runtime_profile` JSONB snapshot

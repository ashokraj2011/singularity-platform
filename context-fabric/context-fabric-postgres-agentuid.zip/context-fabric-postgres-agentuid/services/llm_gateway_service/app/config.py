from __future__ import annotations

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    db_path: str = "./data/llm_gateway.db"
    openrouter_api_key: str = ""
    openrouter_base_url: str = "https://openrouter.ai/api/v1"
    openrouter_app_name: str = "Context Fabric"
    openrouter_site_url: str = "http://localhost:8000"
    openai_compatible_api_key: str = ""
    openai_compatible_base_url: str = "https://api.openai.com/v1"
    ollama_base_url: str = "http://localhost:11434"

    # Anthropic Claude API
    anthropic_api_key: str = ""
    anthropic_base_url: str = "https://api.anthropic.com/v1"
    anthropic_version: str = "2023-06-01"

    # Local/headless CLI providers. These commands must be installed and authenticated
    # wherever llm-gateway-service runs. For Docker, install them in the image or run
    # llm-gateway-service on the host.
    copilot_cli_command: str = "copilot"
    claude_code_cli_command: str = "claude"
    cli_workdir: str = "."
    cli_timeout_seconds: int = 600

    class Config:
        env_prefix = ""
        extra = "ignore"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        import os
        self.db_path = os.getenv("LLM_GATEWAY_DB", self.db_path)


settings = Settings()

from __future__ import annotations

import asyncio
import os
import shlex
import time
from typing import Any

import httpx

from context_fabric_shared.schemas import ChatMessage
from context_fabric_shared.token_counter import count_message_tokens, count_text_tokens
from context_fabric_shared.costs import estimate_cost
from .config import settings


class ProviderError(RuntimeError):
    pass


def _messages_to_dicts(messages: list[ChatMessage]) -> list[dict[str, str]]:
    return [{"role": m.role, "content": m.content} for m in messages]


def _messages_to_prompt(messages: list[ChatMessage]) -> str:
    """Flatten chat messages for headless CLI tools that accept one prompt string."""
    parts: list[str] = []
    for message in messages:
        role = message.role.upper()
        parts.append(f"[{role}]\n{message.content}")
    return "\n\n".join(parts).strip()


def _anthropic_messages(messages: list[ChatMessage]) -> tuple[str | None, list[dict[str, str]]]:
    """Convert Context Fabric messages to Anthropic Messages API shape.

    Anthropic accepts system separately and user/assistant turns in messages.
    Tool messages are folded into user messages for this MVP.
    """
    system_parts: list[str] = []
    converted: list[dict[str, str]] = []
    for message in messages:
        if message.role == "system":
            system_parts.append(message.content)
        elif message.role in {"user", "assistant"}:
            converted.append({"role": message.role, "content": message.content})
        elif message.role == "tool":
            converted.append({"role": "user", "content": f"Tool result:\n{message.content}"})
    return ("\n\n".join(system_parts) if system_parts else None, converted)


async def call_mock(model: str, messages: list[ChatMessage], temperature: float = 0.2, max_tokens: int | None = None) -> dict[str, Any]:
    start = time.perf_counter()
    last_user = next((m.content for m in reversed(messages) if m.role == "user"), "")
    response = (
        "[mock response] Context Fabric received your request. "
        "This mock provider is useful for testing orchestration, context compilation, and token savings without LLM cost.\n\n"
        f"Last user request: {last_user[:800]}"
    )
    input_tokens = count_message_tokens(_messages_to_dicts(messages), model=model)
    output_tokens = count_text_tokens(response, model=model)
    return {
        "response": response,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "estimated_cost": 0.0,
        "latency_ms": int((time.perf_counter() - start) * 1000),
        "raw_provider_response": {"mock": True},
    }


async def call_openrouter(model: str, messages: list[ChatMessage], temperature: float = 0.2, max_tokens: int | None = None) -> dict[str, Any]:
    if not settings.openrouter_api_key:
        raise ProviderError("OPENROUTER_API_KEY is not configured")
    start = time.perf_counter()
    url = settings.openrouter_base_url.rstrip("/") + "/chat/completions"
    headers = {
        "Authorization": f"Bearer {settings.openrouter_api_key}",
        "Content-Type": "application/json",
        "HTTP-Referer": settings.openrouter_site_url,
        "X-Title": settings.openrouter_app_name,
    }
    payload: dict[str, Any] = {
        "model": model,
        "messages": _messages_to_dicts(messages),
        "temperature": temperature,
    }
    if max_tokens:
        payload["max_tokens"] = max_tokens
    async with httpx.AsyncClient(timeout=120.0) as client:
        resp = await client.post(url, headers=headers, json=payload)
        if resp.status_code >= 400:
            raise ProviderError(f"OpenRouter error {resp.status_code}: {resp.text[:1000]}")
        data = resp.json()
    text = data.get("choices", [{}])[0].get("message", {}).get("content", "")
    usage = data.get("usage") or {}
    input_tokens = int(usage.get("prompt_tokens") or count_message_tokens(_messages_to_dicts(messages), model=model))
    output_tokens = int(usage.get("completion_tokens") or count_text_tokens(text, model=model))
    return {
        "response": text,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "estimated_cost": estimate_cost("openrouter", model, input_tokens, output_tokens),
        "latency_ms": int((time.perf_counter() - start) * 1000),
        "raw_provider_response": {"id": data.get("id"), "usage": usage},
    }


async def call_openai_compatible(model: str, messages: list[ChatMessage], temperature: float = 0.2, max_tokens: int | None = None) -> dict[str, Any]:
    if not settings.openai_compatible_api_key:
        raise ProviderError("OPENAI_COMPATIBLE_API_KEY is not configured")
    start = time.perf_counter()
    url = settings.openai_compatible_base_url.rstrip("/") + "/chat/completions"
    headers = {
        "Authorization": f"Bearer {settings.openai_compatible_api_key}",
        "Content-Type": "application/json",
    }
    payload: dict[str, Any] = {
        "model": model,
        "messages": _messages_to_dicts(messages),
        "temperature": temperature,
    }
    if max_tokens:
        payload["max_tokens"] = max_tokens
    async with httpx.AsyncClient(timeout=120.0) as client:
        resp = await client.post(url, headers=headers, json=payload)
        if resp.status_code >= 400:
            raise ProviderError(f"OpenAI-compatible error {resp.status_code}: {resp.text[:1000]}")
        data = resp.json()
    text = data.get("choices", [{}])[0].get("message", {}).get("content", "")
    usage = data.get("usage") or {}
    input_tokens = int(usage.get("prompt_tokens") or count_message_tokens(_messages_to_dicts(messages), model=model))
    output_tokens = int(usage.get("completion_tokens") or count_text_tokens(text, model=model))
    return {
        "response": text,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "estimated_cost": estimate_cost("openai_compatible", model, input_tokens, output_tokens),
        "latency_ms": int((time.perf_counter() - start) * 1000),
        "raw_provider_response": {"id": data.get("id"), "usage": usage},
    }


async def call_anthropic(model: str, messages: list[ChatMessage], temperature: float = 0.2, max_tokens: int | None = None) -> dict[str, Any]:
    """Direct Anthropic Claude Messages API provider."""
    if not settings.anthropic_api_key:
        raise ProviderError("ANTHROPIC_API_KEY is not configured")
    start = time.perf_counter()
    system, anthropic_messages = _anthropic_messages(messages)
    if not anthropic_messages:
        raise ProviderError("Anthropic requires at least one user/assistant message")

    payload: dict[str, Any] = {
        "model": model,
        "messages": anthropic_messages,
        "max_tokens": max_tokens or 1024,
        "temperature": temperature,
    }
    if system:
        payload["system"] = system

    headers = {
        "x-api-key": settings.anthropic_api_key,
        "anthropic-version": settings.anthropic_version,
        "content-type": "application/json",
    }
    url = settings.anthropic_base_url.rstrip("/") + "/messages"
    async with httpx.AsyncClient(timeout=120.0) as client:
        resp = await client.post(url, headers=headers, json=payload)
        if resp.status_code >= 400:
            raise ProviderError(f"Anthropic error {resp.status_code}: {resp.text[:1000]}")
        data = resp.json()

    content_blocks = data.get("content") or []
    text = "".join(block.get("text", "") for block in content_blocks if block.get("type") == "text")
    usage = data.get("usage") or {}
    input_tokens = int(usage.get("input_tokens") or count_message_tokens(_messages_to_dicts(messages), model=model))
    output_tokens = int(usage.get("output_tokens") or count_text_tokens(text, model=model))
    return {
        "response": text,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "estimated_cost": estimate_cost("anthropic", model, input_tokens, output_tokens),
        "latency_ms": int((time.perf_counter() - start) * 1000),
        "raw_provider_response": {"id": data.get("id"), "usage": usage, "stop_reason": data.get("stop_reason")},
    }


async def call_ollama(model: str, messages: list[ChatMessage], temperature: float = 0.2, max_tokens: int | None = None) -> dict[str, Any]:
    start = time.perf_counter()
    url = settings.ollama_base_url.rstrip("/") + "/api/chat"
    payload: dict[str, Any] = {
        "model": model,
        "messages": _messages_to_dicts(messages),
        "stream": False,
        "options": {"temperature": temperature},
    }
    if max_tokens:
        payload["options"]["num_predict"] = max_tokens
    async with httpx.AsyncClient(timeout=240.0) as client:
        resp = await client.post(url, json=payload)
        if resp.status_code >= 400:
            raise ProviderError(f"Ollama error {resp.status_code}: {resp.text[:1000]}")
        data = resp.json()
    text = data.get("message", {}).get("content", "")
    input_tokens = int(data.get("prompt_eval_count") or count_message_tokens(_messages_to_dicts(messages), model=model))
    output_tokens = int(data.get("eval_count") or count_text_tokens(text, model=model))
    return {
        "response": text,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "estimated_cost": 0.0,
        "latency_ms": int((time.perf_counter() - start) * 1000),
        "raw_provider_response": {
            "prompt_eval_count": data.get("prompt_eval_count"),
            "eval_count": data.get("eval_count"),
            "total_duration": data.get("total_duration"),
        },
    }


async def call_cli_provider(provider: str, model: str, messages: list[ChatMessage], temperature: float = 0.2, max_tokens: int | None = None) -> dict[str, Any]:
    """Run an agentic/headless CLI as a provider.

    This is intentionally not treated as a normal LLM API because the CLI may read/write files,
    execute commands, and rely on user-level authentication. Run it in a sandboxed directory.
    """
    start = time.perf_counter()
    prompt = _messages_to_prompt(messages)
    provider = provider.lower().strip()
    if provider in {"copilot_cli", "github_copilot_cli", "copilot"}:
        # GitHub Copilot CLI supports `-p` for non-interactive mode and `-s` for clean output.
        command = [settings.copilot_cli_command, "-p", prompt, "-s"]
    elif provider in {"claude_code_cli", "claude_cli", "claude_code"}:
        # Claude Code supports `-p` / `--print` for non-interactive mode.
        command = [settings.claude_code_cli_command, "-p", prompt]
    else:
        raise ProviderError(f"Unsupported CLI provider: {provider}")

    env = os.environ.copy()
    # Keep CLI tools non-interactive where possible. Individual CLIs may ignore this.
    env.setdefault("NO_COLOR", "1")
    env.setdefault("CI", "1")

    try:
        process = await asyncio.create_subprocess_exec(
            *command,
            cwd=settings.cli_workdir,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
        )
        try:
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=settings.cli_timeout_seconds)
        except asyncio.TimeoutError:
            process.kill()
            await process.wait()
            raise ProviderError(f"CLI provider timed out after {settings.cli_timeout_seconds}s: {shlex.join(command[:2])} ...")
    except FileNotFoundError:
        raise ProviderError(f"CLI command not found: {command[0]}. Install/authenticate it where llm-gateway-service runs.")

    stdout_text = stdout.decode("utf-8", errors="replace").strip()
    stderr_text = stderr.decode("utf-8", errors="replace").strip()
    if process.returncode != 0:
        raise ProviderError(f"CLI provider failed with exit code {process.returncode}: {stderr_text[:1200]}")

    input_tokens = count_message_tokens(_messages_to_dicts(messages), model=model)
    output_tokens = count_text_tokens(stdout_text, model=model)
    return {
        "response": stdout_text,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "estimated_cost": estimate_cost(provider, model, input_tokens, output_tokens),
        "latency_ms": int((time.perf_counter() - start) * 1000),
        "raw_provider_response": {
            "cli_provider": provider,
            "command": command[0],
            "args_preview": command[1:2] + ["<prompt>"] + command[3:],
            "stderr": stderr_text[:2000],
            "token_usage_estimated": True,
        },
    }


async def call_provider(provider: str, model: str, messages: list[ChatMessage], temperature: float = 0.2, max_tokens: int | None = None) -> dict[str, Any]:
    provider = provider.lower().strip()
    if provider == "mock":
        return await call_mock(model, messages, temperature, max_tokens)
    if provider == "openrouter":
        return await call_openrouter(model, messages, temperature, max_tokens)
    if provider in {"openai", "openai_compatible", "compatible"}:
        return await call_openai_compatible(model, messages, temperature, max_tokens)
    if provider in {"anthropic", "claude"}:
        return await call_anthropic(model, messages, temperature, max_tokens)
    if provider == "ollama":
        return await call_ollama(model, messages, temperature, max_tokens)
    if provider in {"copilot_cli", "github_copilot_cli", "copilot", "claude_code_cli", "claude_cli", "claude_code"}:
        return await call_cli_provider(provider, model, messages, temperature, max_tokens)
    raise ProviderError(f"Unsupported provider: {provider}")

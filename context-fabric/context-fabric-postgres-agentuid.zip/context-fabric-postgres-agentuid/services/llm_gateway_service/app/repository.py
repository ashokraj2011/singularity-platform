from __future__ import annotations

import json
from decimal import Decimal
from typing import Any

from context_fabric_shared.identity import scope_dict
from context_fabric_shared.postgres import pg_conn, wait_for_postgres, json_dumps, run_sql_script


def init_db() -> None:
    wait_for_postgres()
    import os
    init_sql_path = "/app/database/init.sql"
    if not os.path.exists(init_sql_path):
        init_sql_path = os.path.abspath(os.path.join(os.getcwd(), "database", "init.sql"))
    with open(init_sql_path, "r", encoding="utf-8") as f:
        sql = f.read()
    run_sql_script(sql)


def _normalize(row: dict | None) -> dict | None:
    if not row:
        return None
    out = dict(row)
    for k, v in list(out.items()):
        if isinstance(v, Decimal):
            out[k] = float(v)
    return out


def insert_model_call(data: dict) -> str:
    metadata = data.get("metadata") or {}
    capability_id = metadata.get("capability_id") or data.get("capability_id")
    agent_id = metadata.get("agent_id") or data.get("agent_id")
    scope = scope_dict(capability_id, agent_id) if capability_id or agent_id else {
        "agent_uid": None, "agent_key": None, "capability_id": capability_id, "agent_id": agent_id
    }
    with pg_conn() as conn:
        row = conn.execute(
            """
            INSERT INTO llm.model_calls
            (agent_uid, agent_key, capability_id, agent_id, session_id, context_package_id,
             provider, model_name, request_json, response_json, input_tokens, output_tokens,
             total_tokens, estimated_cost, latency_ms, status, error, metadata)
            VALUES
            (%(agent_uid)s, %(agent_key)s, %(capability_id)s, %(agent_id)s, %(session_id)s, %(context_package_id)s::uuid,
             %(provider)s, %(model_name)s, %(request_json)s::jsonb, %(response_json)s::jsonb, %(input_tokens)s,
             %(output_tokens)s, %(total_tokens)s, %(estimated_cost)s, %(latency_ms)s, %(status)s, %(error)s, %(metadata)s::jsonb)
            RETURNING id
            """,
            {
                **scope,
                "session_id": metadata.get("session_id") or data.get("session_id"),
                "context_package_id": metadata.get("context_package_id") or data.get("context_package_id"),
                "provider": data["provider"],
                "model_name": data["model_name"],
                "request_json": json_dumps(data.get("request_json") or {}),
                "response_json": json_dumps(data.get("response_json") or {}),
                "input_tokens": data.get("input_tokens"),
                "output_tokens": data.get("output_tokens"),
                "total_tokens": data.get("total_tokens"),
                "estimated_cost": data.get("estimated_cost", 0),
                "latency_ms": data.get("latency_ms"),
                "status": data.get("status", "success"),
                "error": data.get("error"),
                "metadata": json_dumps(metadata),
            },
        ).fetchone()
    return str(row["id"])


def get_model_call(call_id: str) -> dict | None:
    with pg_conn() as conn:
        row = conn.execute(
            """
            SELECT id::text, agent_uid, agent_key, capability_id, agent_id, session_id,
                   context_package_id::text, provider, model_name, request_json, response_json,
                   input_tokens, output_tokens, total_tokens, estimated_cost, latency_ms, status,
                   error, metadata, created_at::text
            FROM llm.model_calls
            WHERE id = %(id)s::uuid
            """,
            {"id": call_id},
        ).fetchone()
    return _normalize(dict(row)) if row else None

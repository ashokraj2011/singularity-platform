from __future__ import annotations

from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import Any

from context_fabric_shared.identity import scope_dict
from .repository import init_db, insert_token_savings_run, get_session_savings, dashboard as dashboard_data

app = FastAPI(title="Context Fabric - Metrics Ledger Service", version="0.3.0")


@app.on_event("startup")
def _startup():
    init_db()


@app.get("/health")
def health():
    return {"status": "ok", "service": "metrics-ledger-service", "storage": "postgres"}


class TokenSavingsRequest(BaseModel):
    session_id: str
    capability_id: str | None = None
    agent_id: str | None = None
    context_package_id: str | None = None
    model_call_id: str | None = None
    client_llm_call_id: str | None = None
    optimization_mode: str
    raw_input_tokens: int
    optimized_input_tokens: int
    output_tokens: int = 0
    tokens_saved: int
    percent_saved: float
    estimated_raw_cost: float = 0.0
    estimated_optimized_cost: float = 0.0
    estimated_cost_saved: float = 0.0
    provider: str | None = None
    model_name: str | None = None
    latency_ms: int | None = None
    quality_score: float | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


@app.post("/metrics/token-savings")
def record_token_savings(req: TokenSavingsRequest):
    run_id = insert_token_savings_run(req.model_dump())
    return {"id": run_id, "status": "recorded"}


@app.get("/metrics/dashboard")
def dashboard():
    return dashboard_data()


@app.get("/metrics/savings/session/{session_id}")
def by_session(session_id: str):
    return {"runs": get_session_savings(session_id)}


@app.get("/metrics/savings/agent/{capability_id}/{agent_id}")
def by_agent(capability_id: str, agent_id: str):
    # Lightweight endpoint that reuses dashboard for now and returns scope info.
    return {"scope": scope_dict(capability_id, agent_id), "message": "Use SQL dashboard/BI for advanced agent aggregations in this MVP."}

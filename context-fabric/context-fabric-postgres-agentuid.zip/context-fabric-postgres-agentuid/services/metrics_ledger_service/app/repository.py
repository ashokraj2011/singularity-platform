from __future__ import annotations

from decimal import Decimal
from typing import Any

from context_fabric_shared.identity import scope_dict
from context_fabric_shared.postgres import pg_conn, wait_for_postgres, json_dumps, run_sql_script


def init_db() -> None:
    wait_for_postgres()
    import os
    init_sql_path = "/app/database/init.sql"
    if not os.path.exists(init_sql_path):
        init_sql_path = os.path.abspath(os.path.join(os.getcwd(), "database", "init.sql"))
    with open(init_sql_path, "r", encoding="utf-8") as f:
        sql = f.read()
    run_sql_script(sql)


def _number(value: Any) -> Any:
    if isinstance(value, Decimal):
        return float(value)
    return value


def insert_token_savings_run(data: dict) -> str:
    scope = scope_dict(data.get("capability_id"), data.get("agent_id")) if data.get("capability_id") or data.get("agent_id") else {
        "agent_uid": data.get("agent_uid"),
        "agent_key": data.get("agent_key"),
        "capability_id": data.get("capability_id"),
        "agent_id": data.get("agent_id"),
    }
    with pg_conn() as conn:
        row = conn.execute(
            """
            INSERT INTO metrics.token_savings_runs
            (agent_uid, agent_key, capability_id, agent_id, session_id, context_package_id,
             model_call_id, client_llm_call_id, optimization_mode, raw_input_tokens,
             optimized_input_tokens, output_tokens, tokens_saved, percent_saved,
             estimated_raw_cost, estimated_optimized_cost, estimated_cost_saved,
             provider, model_name, latency_ms, quality_score, metadata)
            VALUES
            (%(agent_uid)s, %(agent_key)s, %(capability_id)s, %(agent_id)s, %(session_id)s,
             %(context_package_id)s::uuid, %(model_call_id)s, %(client_llm_call_id)s, %(optimization_mode)s,
             %(raw_input_tokens)s, %(optimized_input_tokens)s, %(output_tokens)s, %(tokens_saved)s,
             %(percent_saved)s, %(estimated_raw_cost)s, %(estimated_optimized_cost)s,
             %(estimated_cost_saved)s, %(provider)s, %(model_name)s, %(latency_ms)s,
             %(quality_score)s, %(metadata)s::jsonb)
            RETURNING id
            """,
            {
                **scope,
                "session_id": data["session_id"],
                "context_package_id": data.get("context_package_id"),
                "model_call_id": data.get("model_call_id"),
                "client_llm_call_id": data.get("client_llm_call_id"),
                "optimization_mode": data["optimization_mode"],
                "raw_input_tokens": data["raw_input_tokens"],
                "optimized_input_tokens": data["optimized_input_tokens"],
                "output_tokens": data.get("output_tokens", 0),
                "tokens_saved": data["tokens_saved"],
                "percent_saved": data["percent_saved"],
                "estimated_raw_cost": data.get("estimated_raw_cost", 0.0),
                "estimated_optimized_cost": data.get("estimated_optimized_cost", 0.0),
                "estimated_cost_saved": data.get("estimated_cost_saved", 0.0),
                "provider": data.get("provider"),
                "model_name": data.get("model_name"),
                "latency_ms": data.get("latency_ms"),
                "quality_score": data.get("quality_score"),
                "metadata": json_dumps(data.get("metadata") or {}),
            },
        ).fetchone()
    return str(row["id"])


def get_session_savings(session_id: str) -> list[dict]:
    with pg_conn() as conn:
        rows = conn.execute(
            """
            SELECT id::text, agent_uid, agent_key, capability_id, agent_id, session_id,
                   context_package_id::text, model_call_id, client_llm_call_id, optimization_mode,
                   raw_input_tokens, optimized_input_tokens, output_tokens, tokens_saved,
                   percent_saved::float, estimated_raw_cost::float, estimated_optimized_cost::float,
                   estimated_cost_saved::float, provider, model_name, latency_ms, quality_score::float,
                   metadata, created_at::text
            FROM metrics.token_savings_runs
            WHERE session_id = %(session_id)s
            ORDER BY created_at ASC
            """,
            {"session_id": session_id},
        ).fetchall()
    return [{k: _number(v) for k, v in dict(r).items()} for r in rows]


def dashboard() -> dict:
    with pg_conn() as conn:
        row = conn.execute(
            """
            SELECT
              COUNT(*) AS runs,
              COALESCE(SUM(raw_input_tokens),0) AS total_raw_tokens,
              COALESCE(SUM(optimized_input_tokens),0) AS total_optimized_tokens,
              COALESCE(SUM(output_tokens),0) AS total_output_tokens,
              COALESCE(SUM(tokens_saved),0) AS total_tokens_saved,
              COALESCE(AVG(percent_saved),0) AS average_savings_percent,
              COALESCE(SUM(estimated_cost_saved),0) AS estimated_cost_saved
            FROM metrics.token_savings_runs
            """
        ).fetchone()
        mode = conn.execute(
            """
            SELECT optimization_mode, AVG(percent_saved) AS avg_saved
            FROM metrics.token_savings_runs
            GROUP BY optimization_mode
            ORDER BY avg_saved DESC
            LIMIT 1
            """
        ).fetchone()
    return {**{k: _number(v) for k, v in dict(row).items()}, "best_mode": mode["optimization_mode"] if mode else None}

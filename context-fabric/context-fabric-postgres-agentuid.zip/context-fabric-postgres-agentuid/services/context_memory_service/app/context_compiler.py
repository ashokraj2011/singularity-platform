from __future__ import annotations

from typing import Any

from context_fabric_shared.token_counter import count_message_tokens, count_text_tokens
from context_fabric_shared.hash_utils import sha256_json
from context_fabric_shared.costs import estimate_input_cost
from context_fabric_shared.identity import scope_dict
from .repository import get_messages, get_latest_summary, list_memory_items, insert_context_package
from .memory_search import rank_memory_items
from .summarizer import summary_to_text

DEFAULT_SYSTEM_PROMPT = """You are a helpful assistant using Context Fabric. Use the supplied optimized context carefully. If information is missing, say what is missing instead of inventing details."""

MODE_SETTINGS = {
    "none": {"recent": 999999, "memory": 999999, "summary": False},
    "conservative": {"recent": 12, "memory": 10, "summary": True},
    "medium": {"recent": 6, "memory": 5, "summary": True},
    "aggressive": {"recent": 3, "memory": 3, "summary": True},
    "ultra_aggressive": {"recent": 1, "memory": 2, "summary": True},
    "code_aware": {"recent": 8, "memory": 8, "summary": True},
    "audit_safe": {"recent": 20, "memory": 20, "summary": True},
}


def _to_chat_messages(rows: list[dict]) -> list[dict]:
    return [{"role": r["role"], "content": r["content"]} for r in rows]


def build_raw_context(session_id: str, user_message: str | None = None, system_prompt: str | None = None) -> list[dict]:
    messages = [{"role": "system", "content": system_prompt or DEFAULT_SYSTEM_PROMPT}]
    messages.extend(_to_chat_messages(get_messages(session_id, ascending=True)))
    if user_message:
        messages.append({"role": "user", "content": user_message})
    return messages


def _learning_profile_to_text(runtime_profile: dict[str, Any] | None) -> tuple[str, int | None]:
    if not runtime_profile:
        return "", None
    learning = runtime_profile.get("learning_profile") or {}
    version = learning.get("version")
    summary_text = learning.get("summary_text") or ""
    if summary_text:
        return str(summary_text), int(version) if isinstance(version, int) else None

    # Fallback: compact structured profile.
    parts: list[str] = []
    for key in ("core_principles", "architecture_decisions", "implementation_rules", "tool_usage_guidance", "avoidances"):
        items = learning.get(key) or []
        if items:
            parts.append(f"{key}:")
            for item in items[:8]:
                if isinstance(item, dict):
                    parts.append(f"- {item.get('text') or item.get('content') or item}")
                else:
                    parts.append(f"- {item}")
    return "\n".join(parts).strip(), int(version) if isinstance(version, int) else None


def _format_memory(items: list[dict]) -> str:
    if not items:
        return "No relevant session or temporary memory found."
    lines = []
    for i, item in enumerate(items, start=1):
        cap = item.get("capability_id") or "global"
        agent = item.get("agent_id") or "any-agent"
        lines.append(f"{i}. [{item.get('memory_type')}; capability={cap}; agent={agent}] {item.get('content')}")
    return "\n".join(lines)


def _fit_text_to_budget(text: str, max_tokens: int) -> str:
    tokens = count_text_tokens(text)
    if tokens <= max_tokens:
        return text
    max_chars = max(500, max_tokens * 4)
    return text[:max_chars] + "\n...[trimmed to fit token budget]"


def _dedupe_memory(items: list[dict]) -> list[dict]:
    seen: set[str] = set()
    deduped: list[dict] = []
    for item in items:
        key = item.get("id") or f"{item.get('memory_type')}::{item.get('content')}"
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped


def build_optimized_context(
    session_id: str,
    agent_id: str | None,
    user_message: str,
    mode: str,
    max_context_tokens: int,
    system_prompt: str | None = None,
    capability_id: str | None = None,
    runtime_profile: dict[str, Any] | None = None,
) -> tuple[list[dict], list[str], int | None]:
    mode = mode if mode in MODE_SETTINGS else "medium"
    settings = MODE_SETTINGS[mode]
    included_sections = ["system_prompt", "current_user_message"]

    if mode == "none":
        return build_raw_context(session_id, user_message, system_prompt), ["raw_full_context"], None

    scope = scope_dict(capability_id, agent_id)
    latest_summary = get_latest_summary(session_id)
    summary_text = ""
    if settings["summary"] and latest_summary:
        summary_text = summary_to_text(latest_summary["content"])
        included_sections.append("rolling_session_summary")

    learning_text, learning_version = _learning_profile_to_text(runtime_profile)
    if learning_text:
        included_sections.append("agent_learning_profile")

    recent_rows = get_messages(session_id, limit=settings["recent"], ascending=False)
    recent_messages = _to_chat_messages(recent_rows)
    if recent_messages:
        included_sections.append("recent_messages")

    all_memory: list[dict] = []
    # Context Fabric keeps session-level and temporary memory. Durable profile is supplied by Agent Learning Service.
    all_memory += list_memory_items(agent_uid=scope["agent_uid"], session_id=None, limit=200)
    all_memory += list_memory_items(session_id=session_id, limit=200)
    all_memory = _dedupe_memory(all_memory)

    ranked_memory = rank_memory_items(user_message + "\n" + summary_text + "\n" + learning_text, all_memory, limit=settings["memory"])
    memory_text = _format_memory(ranked_memory)
    if ranked_memory:
        included_sections.append("relevant_context_fabric_memory")

    recent_text = "\n".join([f"{m['role']}: {m['content']}" for m in recent_messages]) or "No recent messages."

    context_block = f"""
[CONTEXT FABRIC OPTIMIZED CONTEXT]
Capability ID: {scope['capability_id']}
Agent ID: {scope['agent_id']}
Agent Key: {scope['agent_key']}
Agent UID: {scope['agent_uid']}
Optimization mode: {mode}

[AGENT LEARNING PROFILE FROM AGENT REGISTRY / LEARNING SERVICE]
{learning_text or 'No external durable learning profile was supplied.'}

[ROLLING SESSION SUMMARY]
{summary_text or 'No rolling session summary yet.'}

[RELEVANT CONTEXT FABRIC MEMORY]
{memory_text}

[RECENT MESSAGES]
{recent_text}

[CURRENT USER MESSAGE]
{user_message}
""".strip()

    reserve = max(1000, int(max_context_tokens * 0.15))
    usable = max(1000, max_context_tokens - reserve - count_text_tokens(system_prompt or DEFAULT_SYSTEM_PROMPT))
    context_block = _fit_text_to_budget(context_block, usable)

    return [
        {"role": "system", "content": system_prompt or DEFAULT_SYSTEM_PROMPT},
        {"role": "user", "content": context_block},
    ], included_sections, learning_version


def compile_context(
    session_id: str,
    agent_id: str | None,
    user_message: str,
    mode: str,
    max_context_tokens: int,
    provider: str = "mock",
    model: str = "mock-fast",
    system_prompt: str | None = None,
    capability_id: str | None = None,
    runtime_profile: dict[str, Any] | None = None,
) -> dict[str, Any]:
    scope = scope_dict(capability_id, agent_id)
    raw_messages = build_raw_context(session_id, user_message=user_message, system_prompt=system_prompt)
    raw_tokens = count_message_tokens(raw_messages, model=model)

    optimized_messages, included_sections, learning_version = build_optimized_context(
        session_id=session_id,
        agent_id=agent_id,
        user_message=user_message,
        mode=mode,
        max_context_tokens=max_context_tokens,
        system_prompt=system_prompt,
        capability_id=capability_id,
        runtime_profile=runtime_profile,
    )
    optimized_tokens = count_message_tokens(optimized_messages, model=model)
    tokens_saved = max(0, raw_tokens - optimized_tokens)
    percent_saved = round((tokens_saved / raw_tokens) * 100, 2) if raw_tokens else 0.0

    raw_cost = estimate_input_cost(provider, model, raw_tokens)
    opt_cost = estimate_input_cost(provider, model, optimized_tokens)
    runtime_profile_hash = sha256_json(runtime_profile or {})

    ctx_id = insert_context_package({
        **scope,
        "session_id": session_id,
        "optimization_mode": mode,
        "compiled_context": optimized_messages,
        "raw_context_hash": sha256_json(raw_messages),
        "optimized_context_hash": sha256_json(optimized_messages),
        "raw_input_tokens": raw_tokens,
        "optimized_input_tokens": optimized_tokens,
        "tokens_saved": tokens_saved,
        "percent_saved": percent_saved,
        "included_sections": included_sections,
        "max_context_tokens": max_context_tokens,
        "agent_learning_profile_version": learning_version,
        "runtime_profile_hash": runtime_profile_hash,
        "runtime_profile": runtime_profile or {},
    })

    return {
        "context_package_id": ctx_id,
        **scope,
        "messages": optimized_messages,
        "included_sections": included_sections,
        "agent_learning_profile_version": learning_version,
        "runtime_profile_hash": runtime_profile_hash,
        "optimization": {
            "mode": mode,
            **scope,
            "raw_input_tokens": raw_tokens,
            "optimized_input_tokens": optimized_tokens,
            "tokens_saved": tokens_saved,
            "percent_saved": percent_saved,
            "estimated_raw_cost": raw_cost,
            "estimated_optimized_cost": opt_cost,
            "estimated_cost_saved": round(max(0.0, raw_cost - opt_cost), 8),
        },
    }

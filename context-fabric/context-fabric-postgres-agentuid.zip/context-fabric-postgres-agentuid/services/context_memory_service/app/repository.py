from __future__ import annotations

import json
from decimal import Decimal
from typing import Any

from context_fabric_shared.identity import scope_dict
from context_fabric_shared.postgres import pg_conn, wait_for_postgres, json_dumps, run_sql_script
from context_fabric_shared.token_counter import count_text_tokens


def init_db() -> None:
    wait_for_postgres()
    init_sql_path = "/app/database/init.sql"
    # In local PyCharm runs, database/init.sql is relative to repo root.
    import os
    if not os.path.exists(init_sql_path):
        init_sql_path = os.path.abspath(os.path.join(os.getcwd(), "database", "init.sql"))
    with open(init_sql_path, "r", encoding="utf-8") as f:
        sql = f.read()
    run_sql_script(sql)


def _scope(capability_id: str | None, agent_id: str | None) -> dict[str, str]:
    return scope_dict(capability_id, agent_id)


def _json_load(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, (dict, list)):
        return value
    return json.loads(value)


def _normalize_row(row: dict | None) -> dict | None:
    if not row:
        return None
    out = dict(row)
    for k, v in list(out.items()):
        if isinstance(v, Decimal):
            out[k] = float(v)
    return out


def insert_message(
    session_id: str,
    agent_id: str | None,
    role: str,
    content: str,
    token_count: int | None = None,
    capability_id: str | None = None,
    metadata: dict | None = None,
    provider: str | None = None,
    model_name: str | None = None,
) -> str:
    scope = _scope(capability_id, agent_id)
    token_count = token_count if token_count is not None else count_text_tokens(content)
    with pg_conn() as conn:
        row = conn.execute(
            """
            INSERT INTO memory.conversation_messages
            (agent_uid, agent_key, capability_id, agent_id, session_id, role, content, token_count, provider, model_name, metadata)
            VALUES (%(agent_uid)s, %(agent_key)s, %(capability_id)s, %(agent_id)s, %(session_id)s, %(role)s, %(content)s, %(token_count)s, %(provider)s, %(model_name)s, %(metadata)s::jsonb)
            RETURNING id
            """,
            {**scope, "session_id": session_id, "role": role, "content": content, "token_count": token_count,
             "provider": provider, "model_name": model_name, "metadata": json_dumps(metadata or {})},
        ).fetchone()
    return str(row["id"])


def get_messages(session_id: str, limit: int | None = None, ascending: bool = True) -> list[dict]:
    order = "ASC" if ascending else "DESC"
    sql = f"""
        SELECT id::text, agent_uid, agent_key, capability_id, agent_id, session_id, role, content,
               token_count, provider, model_name, metadata, created_at::text
        FROM memory.conversation_messages
        WHERE session_id = %(session_id)s
        ORDER BY created_at {order}
    """
    params: dict[str, Any] = {"session_id": session_id}
    if limit is not None:
        sql += " LIMIT %(limit)s"
        params["limit"] = limit
    with pg_conn() as conn:
        rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
    if not ascending:
        rows = list(reversed(rows))
    return rows


def get_message_stats(session_id: str) -> dict:
    latest = get_latest_summary(session_id)
    with pg_conn() as conn:
        total = conn.execute(
            "SELECT COUNT(*) AS cnt, COALESCE(SUM(token_count),0) AS tokens FROM memory.conversation_messages WHERE session_id=%(session_id)s",
            {"session_id": session_id},
        ).fetchone()
        if latest:
            since = conn.execute(
                "SELECT COUNT(*) AS cnt FROM memory.conversation_messages WHERE session_id=%(session_id)s AND created_at > %(created_at)s::timestamptz",
                {"session_id": session_id, "created_at": latest["created_at"]},
            ).fetchone()["cnt"]
        else:
            since = total["cnt"]
    return {"message_count": int(total["cnt"]), "total_tokens": int(total["tokens"] or 0), "messages_since_summary": int(since)}


def next_summary_version(session_id: str) -> int:
    with pg_conn() as conn:
        row = conn.execute(
            "SELECT COALESCE(MAX(version),0) + 1 AS next_version FROM memory.context_summaries WHERE session_id=%(session_id)s",
            {"session_id": session_id},
        ).fetchone()
    return int(row["next_version"])


def insert_summary(
    session_id: str,
    agent_id: str | None,
    summary_type: str,
    content: dict,
    token_count: int | None,
    capability_id: str | None = None,
    metadata: dict | None = None,
) -> str:
    scope = _scope(capability_id, agent_id)
    version = next_summary_version(session_id)
    with pg_conn() as conn:
        row = conn.execute(
            """
            INSERT INTO memory.context_summaries
            (agent_uid, agent_key, capability_id, agent_id, session_id, summary_type, version, content, token_count, metadata)
            VALUES (%(agent_uid)s, %(agent_key)s, %(capability_id)s, %(agent_id)s, %(session_id)s, %(summary_type)s, %(version)s, %(content)s::jsonb, %(token_count)s, %(metadata)s::jsonb)
            RETURNING id
            """,
            {**scope, "session_id": session_id, "summary_type": summary_type, "version": version,
             "content": json_dumps(content), "token_count": token_count, "metadata": json_dumps(metadata or {})},
        ).fetchone()
    return str(row["id"])


def get_latest_summary(session_id: str) -> dict | None:
    with pg_conn() as conn:
        row = conn.execute(
            """
            SELECT id::text, agent_uid, agent_key, capability_id, agent_id, session_id, summary_type,
                   version, content, token_count, metadata, created_at::text
            FROM memory.context_summaries
            WHERE session_id=%(session_id)s
            ORDER BY version DESC
            LIMIT 1
            """,
            {"session_id": session_id},
        ).fetchone()
    return _normalize_row(dict(row)) if row else None


def insert_memory_item(data: dict) -> str:
    scope = _scope(data.get("capability_id"), data.get("agent_id")) if data.get("capability_id") or data.get("agent_id") else {
        "agent_uid": data.get("agent_uid"),
        "agent_key": data.get("agent_key"),
        "capability_id": data.get("capability_id"),
        "agent_id": data.get("agent_id"),
    }
    with pg_conn() as conn:
        row = conn.execute(
            """
            INSERT INTO memory.memory_items
            (agent_uid, agent_key, capability_id, agent_id, session_id, project_id, memory_type, content,
             content_json, importance_score, confidence, source_type, source_id, metadata)
            VALUES (%(agent_uid)s, %(agent_key)s, %(capability_id)s, %(agent_id)s, %(session_id)s, %(project_id)s,
                    %(memory_type)s, %(content)s, %(content_json)s::jsonb, %(importance_score)s, %(confidence)s,
                    %(source_type)s, %(source_id)s, %(metadata)s::jsonb)
            RETURNING id
            """,
            {
                **scope,
                "session_id": data.get("session_id"),
                "project_id": data.get("project_id"),
                "memory_type": data["memory_type"],
                "content": data["content"],
                "content_json": json_dumps(data.get("content_json")),
                "importance_score": data.get("importance_score", 0.5),
                "confidence": data.get("confidence", 0.8),
                "source_type": data.get("source_type"),
                "source_id": data.get("source_id"),
                "metadata": json_dumps(data.get("metadata") or {}),
            },
        ).fetchone()
    return str(row["id"])


def list_memory_items(
    agent_id: str | None = None,
    session_id: str | None = None,
    capability_id: str | None = None,
    agent_uid: str | None = None,
    limit: int = 100,
) -> list[dict]:
    clauses: list[str] = []
    params: dict[str, Any] = {"limit": limit}
    if agent_uid:
        clauses.append("agent_uid = %(agent_uid)s")
        params["agent_uid"] = agent_uid
    elif capability_id and agent_id:
        scope = _scope(capability_id, agent_id)
        clauses.append("agent_uid = %(agent_uid)s")
        params["agent_uid"] = scope["agent_uid"]
    elif agent_id:
        clauses.append("agent_id = %(agent_id)s")
        params["agent_id"] = agent_id
    if session_id:
        clauses.append("session_id = %(session_id)s")
        params["session_id"] = session_id
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    with pg_conn() as conn:
        rows = conn.execute(
            f"""
            SELECT id::text, agent_uid, agent_key, capability_id, agent_id, session_id, project_id,
                   memory_type, content, content_json, importance_score::float, confidence::float,
                   source_type, source_id, metadata, created_at::text
            FROM memory.memory_items
            {where}
            ORDER BY importance_score DESC, created_at DESC
            LIMIT %(limit)s
            """,
            params,
        ).fetchall()
    return [_normalize_row(dict(r)) for r in rows]


def insert_context_package(data: dict) -> str:
    scope = _scope(data.get("capability_id"), data.get("agent_id"))
    with pg_conn() as conn:
        row = conn.execute(
            """
            INSERT INTO context.context_packages
            (agent_uid, agent_key, capability_id, agent_id, session_id, optimization_mode,
             compiled_context, included_sections, raw_context_hash, optimized_context_hash,
             raw_input_tokens, optimized_input_tokens, tokens_saved, percent_saved, max_context_tokens,
             agent_learning_profile_version, runtime_profile_hash, runtime_profile, metadata)
            VALUES
            (%(agent_uid)s, %(agent_key)s, %(capability_id)s, %(agent_id)s, %(session_id)s, %(optimization_mode)s,
             %(compiled_context)s::jsonb, %(included_sections)s::jsonb, %(raw_context_hash)s, %(optimized_context_hash)s,
             %(raw_input_tokens)s, %(optimized_input_tokens)s, %(tokens_saved)s, %(percent_saved)s, %(max_context_tokens)s,
             %(agent_learning_profile_version)s, %(runtime_profile_hash)s, %(runtime_profile)s::jsonb, %(metadata)s::jsonb)
            RETURNING id
            """,
            {
                **scope,
                "session_id": data["session_id"],
                "optimization_mode": data["optimization_mode"],
                "compiled_context": json_dumps(data["compiled_context"]),
                "included_sections": json_dumps(data.get("included_sections", [])),
                "raw_context_hash": data.get("raw_context_hash"),
                "optimized_context_hash": data.get("optimized_context_hash"),
                "raw_input_tokens": data["raw_input_tokens"],
                "optimized_input_tokens": data["optimized_input_tokens"],
                "tokens_saved": data["tokens_saved"],
                "percent_saved": data["percent_saved"],
                "max_context_tokens": data.get("max_context_tokens"),
                "agent_learning_profile_version": data.get("agent_learning_profile_version"),
                "runtime_profile_hash": data.get("runtime_profile_hash"),
                "runtime_profile": json_dumps(data.get("runtime_profile") or {}),
                "metadata": json_dumps(data.get("metadata") or {}),
            },
        ).fetchone()
    return str(row["id"])


def get_context_package(context_package_id: str) -> dict | None:
    with pg_conn() as conn:
        row = conn.execute(
            """
            SELECT id::text, agent_uid, agent_key, capability_id, agent_id, session_id,
                   optimization_mode, compiled_context, included_sections,
                   raw_input_tokens, optimized_input_tokens, tokens_saved, percent_saved::float,
                   max_context_tokens, agent_learning_profile_version, runtime_profile_hash,
                   runtime_profile, metadata, created_at::text
            FROM context.context_packages
            WHERE id = %(id)s::uuid
            """,
            {"id": context_package_id},
        ).fetchone()
    return _normalize_row(dict(row)) if row else None

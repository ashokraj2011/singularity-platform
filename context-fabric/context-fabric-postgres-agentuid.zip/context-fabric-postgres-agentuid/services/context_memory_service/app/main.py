from __future__ import annotations

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Any

from context_fabric_shared.identity import scope_dict
from context_fabric_shared.token_counter import count_text_tokens
from .repository import (
    init_db,
    insert_message,
    get_messages,
    get_message_stats,
    insert_summary,
    get_latest_summary,
    insert_memory_item,
    list_memory_items,
    get_context_package,
)
from .summarizer import summarize_with_llm, summary_token_count
from .context_compiler import compile_context
from .memory_search import rank_memory_items

app = FastAPI(title="Context Fabric - Context Memory Service", version="0.3.0")


@app.on_event("startup")
def _startup():
    init_db()


@app.get("/health")
def health():
    return {"status": "ok", "service": "context-memory-service", "storage": "postgres-jsonb-pgvector-ready"}


class MessageRequest(BaseModel):
    session_id: str
    capability_id: str = "default-capability"
    agent_id: str = "default-agent"
    role: str
    content: str
    metadata: dict[str, Any] = Field(default_factory=dict)
    provider: str | None = None
    model_name: str | None = None


@app.post("/memory/messages")
def save_message(req: MessageRequest):
    mid = insert_message(
        session_id=req.session_id,
        capability_id=req.capability_id,
        agent_id=req.agent_id,
        role=req.role,
        content=req.content,
        token_count=count_text_tokens(req.content),
        metadata=req.metadata,
        provider=req.provider,
        model_name=req.model_name,
    )
    return {"id": mid, "status": "saved", **scope_dict(req.capability_id, req.agent_id)}


@app.get("/memory/messages/{session_id}")
def read_messages(session_id: str, limit: int | None = None):
    return {"messages": get_messages(session_id, limit=limit, ascending=True)}


@app.get("/memory/messages/{session_id}/stats")
def message_stats(session_id: str):
    return {"session_id": session_id, **get_message_stats(session_id)}


class SummaryUpdateRequest(BaseModel):
    session_id: str
    capability_id: str = "default-capability"
    agent_id: str = "default-agent"
    force: bool = False
    min_messages_since_last_summary: int = 8


@app.post("/memory/summaries/update")
async def update_summary(req: SummaryUpdateRequest):
    stats = get_message_stats(req.session_id)
    since = stats["messages_since_summary"]
    if not req.force and since < req.min_messages_since_last_summary:
        latest = get_latest_summary(req.session_id)
        return {"updated": False, "reason": "threshold_not_met", "messages_since_summary": since, "latest_summary": latest}

    messages = get_messages(req.session_id, ascending=True)
    if not messages:
        raise HTTPException(status_code=400, detail="No messages to summarize")

    summary = await summarize_with_llm(messages, agent_id=req.agent_id)
    sid = insert_summary(
        session_id=req.session_id,
        capability_id=req.capability_id,
        agent_id=req.agent_id,
        summary_type="rolling",
        content=summary,
        token_count=summary_token_count(summary),
    )

    # Store durable candidates as temporary context-fabric memory. Source of truth for durable profiles is external Agent Learning Service.
    for item in summary.get("durable_learning", [])[:10]:
        if isinstance(item, str) and item.strip():
            insert_memory_item({
                "session_id": req.session_id,
                "capability_id": req.capability_id,
                "agent_id": req.agent_id,
                "memory_type": "learning_candidate",
                "content": item.strip(),
                "importance_score": 0.7,
                "confidence": 0.7,
                "source_type": "summary",
                "source_id": sid,
                "metadata": {"note": "Candidate only. Durable learning is owned by Agent Registry / Learning Service."},
            })

    return {"updated": True, "summary_id": sid, "summary": summary, **scope_dict(req.capability_id, req.agent_id)}


@app.get("/memory/summaries/latest/{session_id}")
def latest_summary(session_id: str):
    return {"summary": get_latest_summary(session_id)}


class MemoryItemRequest(BaseModel):
    session_id: str | None = None
    capability_id: str | None = None
    agent_id: str | None = None
    project_id: str | None = None
    memory_type: str
    content: str
    content_json: dict[str, Any] | None = None
    importance_score: float = 0.5
    confidence: float = 0.8
    source_type: str | None = None
    source_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


@app.post("/memory/items")
def save_memory_item(req: MemoryItemRequest):
    mid = insert_memory_item(req.model_dump())
    return {"id": mid, "status": "saved"}


class MemorySearchRequest(BaseModel):
    query: str
    capability_id: str | None = None
    agent_id: str | None = None
    session_id: str | None = None
    limit: int = 5


@app.post("/memory/search")
def search_memory(req: MemorySearchRequest):
    scope = scope_dict(req.capability_id, req.agent_id) if req.capability_id and req.agent_id else {}
    candidates = []
    if scope:
        candidates.extend(list_memory_items(agent_uid=scope["agent_uid"], limit=200))
    if req.session_id:
        candidates.extend(list_memory_items(session_id=req.session_id, limit=200))
    ranked = rank_memory_items(req.query, candidates, limit=req.limit)
    return {"items": ranked, "scope": scope}


class CompileRequest(BaseModel):
    session_id: str
    capability_id: str = "default-capability"
    agent_id: str = "default-agent"
    user_message: str
    optimization_mode: str = "medium"
    compare_with_raw: bool = True
    max_context_tokens: int = 16000
    provider: str = "mock"
    model: str = "mock-fast"
    system_prompt: str | None = None
    runtime_profile: dict[str, Any] = Field(default_factory=dict)


@app.post("/context/compile")
def compile(req: CompileRequest):
    return compile_context(
        session_id=req.session_id,
        capability_id=req.capability_id,
        agent_id=req.agent_id,
        user_message=req.user_message,
        mode=req.optimization_mode,
        max_context_tokens=req.max_context_tokens,
        provider=req.provider,
        model=req.model,
        system_prompt=req.system_prompt,
        runtime_profile=req.runtime_profile,
    )


class CompareRequest(BaseModel):
    session_id: str
    capability_id: str = "default-capability"
    agent_id: str = "default-agent"
    message: str
    modes: list[str] = Field(default_factory=lambda: ["none", "conservative", "medium", "aggressive"])
    max_context_tokens: int = 16000
    provider: str = "mock"
    model: str = "mock-fast"
    system_prompt: str | None = None
    runtime_profile: dict[str, Any] = Field(default_factory=dict)


@app.post("/context/compare")
def compare(req: CompareRequest):
    comparisons = []
    best = None
    for mode in req.modes:
        result = compile_context(
            session_id=req.session_id,
            capability_id=req.capability_id,
            agent_id=req.agent_id,
            user_message=req.message,
            mode=mode,
            max_context_tokens=req.max_context_tokens,
            provider=req.provider,
            model=req.model,
            system_prompt=req.system_prompt,
            runtime_profile=req.runtime_profile,
        )
        opt = result["optimization"]
        comparisons.append(opt)
        if mode != "none" and (best is None or opt["percent_saved"] > best["percent_saved"]):
            best = opt

    recommended = "medium"
    if best and best["percent_saved"] > 85:
        recommended = "aggressive"
    elif best and best["percent_saved"] > 60:
        recommended = "medium"
    elif best:
        recommended = "conservative"

    return {"comparisons": comparisons, "recommended_mode": recommended}


@app.get("/context/packages/{context_package_id}")
def read_context_package(context_package_id: str):
    package = get_context_package(context_package_id)
    if not package:
        raise HTTPException(status_code=404, detail="Context package not found")
    return package

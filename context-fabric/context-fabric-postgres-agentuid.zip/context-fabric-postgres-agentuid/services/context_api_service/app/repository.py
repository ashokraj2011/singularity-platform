from __future__ import annotations

from typing import Any
from context_fabric_shared.identity import scope_dict
from context_fabric_shared.postgres import pg_conn, wait_for_postgres, json_dumps, run_sql_script
from context_fabric_shared.hash_utils import sha256_json


def init_db() -> None:
    wait_for_postgres()
    import os
    init_sql_path = "/app/database/init.sql"
    if not os.path.exists(init_sql_path):
        init_sql_path = os.path.abspath(os.path.join(os.getcwd(), "database", "init.sql"))
    with open(init_sql_path, "r", encoding="utf-8") as f:
        sql = f.read()
    run_sql_script(sql)


def insert_client_llm_call(data: dict[str, Any]) -> str:
    scope = scope_dict(data.get("capability_id"), data.get("agent_id"))
    prepared = data["prepared_call"]
    opt = data.get("optimization") or {}
    with pg_conn() as conn:
        row = conn.execute(
            """
            INSERT INTO llm.client_llm_calls
            (agent_uid, agent_key, capability_id, agent_id, session_id, context_package_id,
             provider, model_name, status, prepared_call_json, raw_input_tokens,
             optimized_input_tokens, tokens_saved, percent_saved, prepared_call_hash, metadata)
            VALUES
            (%(agent_uid)s, %(agent_key)s, %(capability_id)s, %(agent_id)s, %(session_id)s,
             %(context_package_id)s::uuid, %(provider)s, %(model_name)s, 'pending',
             %(prepared_call_json)s::jsonb, %(raw_input_tokens)s, %(optimized_input_tokens)s,
             %(tokens_saved)s, %(percent_saved)s, %(prepared_call_hash)s, %(metadata)s::jsonb)
            RETURNING id
            """,
            {
                **scope,
                "session_id": data["session_id"],
                "context_package_id": data["context_package_id"],
                "provider": data["provider"],
                "model_name": data["model"],
                "prepared_call_json": json_dumps(prepared),
                "raw_input_tokens": opt.get("raw_input_tokens"),
                "optimized_input_tokens": opt.get("optimized_input_tokens"),
                "tokens_saved": opt.get("tokens_saved"),
                "percent_saved": opt.get("percent_saved"),
                "prepared_call_hash": sha256_json(prepared),
                "metadata": json_dumps(data.get("metadata") or {}),
            },
        ).fetchone()
    return str(row["id"])


def complete_client_llm_call(client_call_id: str, data: dict[str, Any]) -> None:
    with pg_conn() as conn:
        conn.execute(
            """
            UPDATE llm.client_llm_calls
            SET status = 'completed',
                result_json = %(result_json)s::jsonb,
                output_tokens = %(output_tokens)s,
                result_hash = %(result_hash)s,
                completed_at = now(),
                error = NULL
            WHERE id = %(id)s::uuid
            """,
            {
                "id": client_call_id,
                "result_json": json_dumps(data),
                "output_tokens": (data.get("usage") or {}).get("output_tokens") or (data.get("usage") or {}).get("completion_tokens") or 0,
                "result_hash": sha256_json(data),
            },
        )


def fail_client_llm_call(client_call_id: str, error: str, payload: dict[str, Any] | None = None) -> None:
    with pg_conn() as conn:
        conn.execute(
            """
            UPDATE llm.client_llm_calls
            SET status = 'failed',
                result_json = %(result_json)s::jsonb,
                error = %(error)s,
                completed_at = now()
            WHERE id = %(id)s::uuid
            """,
            {"id": client_call_id, "error": error, "result_json": json_dumps(payload or {})},
        )

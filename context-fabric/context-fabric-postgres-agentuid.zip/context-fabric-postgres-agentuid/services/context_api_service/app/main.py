from __future__ import annotations

import uuid
from typing import Any

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from context_fabric_shared.identity import scope_dict
from context_fabric_shared.schemas import ContextPolicy
from context_fabric_shared.http_client import post_json, get_json
from .config import settings
from .repository import init_db, insert_client_llm_call, complete_client_llm_call as mark_client_call_complete, fail_client_llm_call as mark_client_call_failed

app = FastAPI(title="Context Fabric - Context API Service", version="0.3.0")


@app.on_event("startup")
def _startup():
    init_db()


@app.get("/health")
def health():
    return {"status": "ok", "service": "context-api-service", "storage": "postgres", "agent_learning_service_url": settings.agent_learning_service_url}


class LLMExecutionPolicy(BaseModel):
    mode: str = "server"  # server | return_call | compile_only
    include_compiled_context: bool = True
    create_pending_record: bool = True


class ChatRespondRequest(BaseModel):
    session_id: str
    capability_id: str = "default-capability"
    agent_id: str = "default-agent"
    message: str
    provider: str | None = None
    model: str | None = None
    temperature: float = 0.2
    max_output_tokens: int | None = None
    system_prompt: str | None = None
    context_policy: ContextPolicy = Field(default_factory=ContextPolicy)
    llm_execution: LLMExecutionPolicy = Field(default_factory=LLMExecutionPolicy)
    summarization: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ChatRespondResponse(BaseModel):
    response: str
    session_id: str
    capability_id: str
    agent_id: str
    agent_key: str
    agent_uid: str
    context_package_id: str
    model_call_id: str
    optimization: dict[str, Any]
    model_usage: dict[str, Any]
    metrics_run_id: str | None = None


class ClientLLMCompleteRequest(BaseModel):
    session_id: str
    capability_id: str = "default-capability"
    agent_id: str = "default-agent"
    context_package_id: str
    provider: str
    model: str
    response_text: str
    raw_provider_response: dict[str, Any] = Field(default_factory=dict)
    usage: dict[str, Any] = Field(default_factory=dict)
    optimization: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


async def fetch_runtime_profile(capability_id: str, agent_id: str) -> dict[str, Any]:
    scope = scope_dict(capability_id, agent_id)
    if not settings.agent_learning_service_url:
        return {
            **scope,
            "system_prompt": None,
            "default_provider": None,
            "default_model": None,
            "default_context_mode": None,
            "allowed_tools": [],
            "learning_profile": {},
            "source": "default-local-fallback",
        }
    try:
        url = settings.agent_learning_service_url.rstrip() + "/runtime-profile"
        # direct URL building because the MVP helper does not support query params.
        return await get_json(
            f"{settings.agent_learning_service_url.rstrip('/')}/runtime-profile?capability_id={capability_id}&agent_id={agent_id}",
            timeout=30.0,
        )
    except Exception as exc:
        return {**scope, "learning_profile": {}, "source": "agent-learning-service-unavailable", "error": str(exc)}


async def maybe_update_summary(session_id: str, capability_id: str, agent_id: str, force: bool = False) -> dict:
    try:
        stats = await get_json(f"{settings.context_memory_url.rstrip('/')}/memory/messages/{session_id}/stats")
        should = force or stats.get("messages_since_summary", 0) >= 8 or stats.get("total_tokens", 0) >= 24000
        if should:
            return await post_json(
                f"{settings.context_memory_url.rstrip('/')}/memory/summaries/update",
                {"session_id": session_id, "capability_id": capability_id, "agent_id": agent_id, "force": force},
                timeout=180.0,
            )
        return {"updated": False, "reason": "threshold_not_met", "stats": stats}
    except Exception as e:
        return {"updated": False, "reason": "summary_error", "error": str(e)}


async def submit_learning_candidates(req: ClientLLMCompleteRequest) -> None:
    # Context Fabric only forwards candidates. Durable versioning is owned by Agent Registry / Learning Service.
    if not settings.agent_learning_service_url:
        return
    candidates = req.metadata.get("learning_candidates") or []
    if not candidates:
        return
    try:
        await post_json(
            f"{settings.agent_learning_service_url.rstrip('/')}/learning-candidates",
            {
                "capability_id": req.capability_id,
                "agent_id": req.agent_id,
                "agent_uid": scope_dict(req.capability_id, req.agent_id)["agent_uid"],
                "session_id": req.session_id,
                "source_context_package_id": req.context_package_id,
                "source_type": "client_llm_response",
                "candidates": candidates,
            },
            timeout=30.0,
        )
    except Exception:
        return


def _chat_messages_to_prompt(messages: list[dict[str, Any]]) -> str:
    return "\n\n".join(f"[{m.get('role','').upper()}]\n{m.get('content','')}" for m in messages).strip()


def _openai_compatible_call(provider: str, base_url: str, model: str, messages: list[dict[str, Any]], temperature: float, max_output_tokens: int | None, extra_headers: dict[str, str] | None = None) -> dict[str, Any]:
    body: dict[str, Any] = {"model": model, "messages": messages, "temperature": temperature}
    if max_output_tokens is not None:
        body["max_tokens"] = max_output_tokens
    return {
        "execution_type": "http",
        "provider": provider,
        "method": "POST",
        "url": base_url.rstrip("/") + "/chat/completions",
        "auth": {"type": "bearer", "header": "Authorization", "value_source": "client"},
        "headers": {"Content-Type": "application/json", **(extra_headers or {})},
        "body": body,
    }


def build_prepared_llm_call(provider: str, model: str, messages: list[dict[str, Any]], temperature: float, max_output_tokens: int | None) -> dict[str, Any]:
    provider_key = provider.lower().strip()
    if provider_key in {"openai", "openai_compatible", "compatible"}:
        return _openai_compatible_call(provider, "https://api.openai.com/v1", model, messages, temperature, max_output_tokens)
    if provider_key == "openrouter":
        return _openai_compatible_call(provider, "https://openrouter.ai/api/v1", model, messages, temperature, max_output_tokens, {"HTTP-Referer": "http://localhost:8000", "X-Title": "Context Fabric"})
    if provider_key in {"anthropic", "claude"}:
        system_parts: list[str] = []
        anthropic_messages: list[dict[str, str]] = []
        for msg in messages:
            role = str(msg.get("role", ""))
            content = str(msg.get("content", ""))
            if role == "system":
                system_parts.append(content)
            elif role in {"user", "assistant"}:
                anthropic_messages.append({"role": role, "content": content})
        return {
            "execution_type": "http",
            "provider": provider,
            "method": "POST",
            "url": "https://api.anthropic.com/v1/messages",
            "auth": {"type": "x-api-key", "header": "x-api-key", "value_source": "client"},
            "headers": {"Content-Type": "application/json", "anthropic-version": "2023-06-01"},
            "body": {"model": model, "system": "\n\n".join(system_parts).strip(), "messages": anthropic_messages, "temperature": temperature, "max_tokens": max_output_tokens or 1200},
        }
    if provider_key == "ollama":
        return {"execution_type": "http", "provider": provider, "method": "POST", "url": "http://localhost:11434/api/chat", "auth": {"type": "none"}, "headers": {"Content-Type": "application/json"}, "body": {"model": model, "messages": messages, "stream": False, "options": {"temperature": temperature}}}
    if provider_key in {"copilot_client", "copilot_cli"}:
        prompt = _chat_messages_to_prompt(messages)
        return {"execution_type": "local_command", "provider": provider, "command": "copilot", "args_template": ["-p", "{{prompt}}", "-s"], "prompt": prompt, "requires_local_runner": True, "requires_workspace": True, "auth": {"type": "local_cli_auth", "value_source": "client"}}
    if provider_key in {"claude_code_client", "claude_code_cli"}:
        prompt = _chat_messages_to_prompt(messages)
        return {"execution_type": "local_command", "provider": provider, "command": "claude", "args_template": ["-p", "{{prompt}}"], "prompt": prompt, "requires_local_runner": True, "requires_workspace": True, "auth": {"type": "local_cli_auth", "value_source": "client"}}
    if provider_key in {"codex_client", "codex_cli"}:
        prompt = _chat_messages_to_prompt(messages)
        return {"execution_type": "local_command", "provider": provider, "command": "codex", "args_template": ["exec", "{{prompt}}"], "prompt": prompt, "requires_local_runner": True, "requires_workspace": True, "auth": {"type": "local_cli_auth", "value_source": "client"}}
    raise ValueError(f"Unsupported provider for return_call mode: {provider}")


@app.post("/chat/respond")
async def chat_respond(req: ChatRespondRequest):
    memory_url = settings.context_memory_url.rstrip("/")
    llm_url = settings.llm_gateway_url.rstrip("/")
    metrics_url = settings.metrics_ledger_url.rstrip("/")
    scope = scope_dict(req.capability_id, req.agent_id)

    runtime_profile = await fetch_runtime_profile(req.capability_id, req.agent_id)
    provider = req.provider or runtime_profile.get("default_provider") or "mock"
    model = req.model or runtime_profile.get("default_model") or "mock-fast"
    system_prompt = req.system_prompt or runtime_profile.get("system_prompt")
    context_mode = req.context_policy.optimization_mode
    if context_mode == "auto":
        context_mode = runtime_profile.get("default_context_mode") or "medium"

    await post_json(f"{memory_url}/memory/messages", {
        "session_id": req.session_id,
        "capability_id": req.capability_id,
        "agent_id": req.agent_id,
        "role": "user",
        "content": req.message,
    })

    force_summary = bool(req.summarization.get("force", False))
    await maybe_update_summary(req.session_id, req.capability_id, req.agent_id, force=force_summary)

    compiled = await post_json(f"{memory_url}/context/compile", {
        "session_id": req.session_id,
        "capability_id": req.capability_id,
        "agent_id": req.agent_id,
        "user_message": req.message,
        "optimization_mode": context_mode,
        "compare_with_raw": req.context_policy.compare_with_raw,
        "max_context_tokens": req.context_policy.max_context_tokens,
        "provider": provider,
        "model": model,
        "system_prompt": system_prompt,
        "runtime_profile": runtime_profile,
    })

    execution_mode = req.llm_execution.mode.lower().strip()

    if execution_mode == "compile_only":
        return {"status": "compiled_context_ready", "session_id": req.session_id, **scope, "context_package_id": compiled["context_package_id"], "messages": compiled["messages"] if req.llm_execution.include_compiled_context else None, "optimization": compiled["optimization"], "runtime_profile": runtime_profile}

    if execution_mode == "return_call":
        try:
            prepared_call = build_prepared_llm_call(provider, model, compiled["messages"], req.temperature, req.max_output_tokens)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e)) from e

        client_model_call_id = insert_client_llm_call({
            "session_id": req.session_id,
            "capability_id": req.capability_id,
            "agent_id": req.agent_id,
            "context_package_id": compiled["context_package_id"],
            "provider": provider,
            "model": model,
            "prepared_call": prepared_call,
            "optimization": compiled["optimization"],
            "metadata": {"runtime_profile_hash": compiled.get("runtime_profile_hash"), **req.metadata},
        })

        return {
            "status": "client_llm_call_required",
            "session_id": req.session_id,
            **scope,
            "context_package_id": compiled["context_package_id"],
            "client_model_call_id": client_model_call_id,
            "provider": provider,
            "model": model,
            "optimization": compiled["optimization"],
            "runtime_profile": runtime_profile,
            "messages": compiled["messages"] if req.llm_execution.include_compiled_context else None,
            "prepared_call": prepared_call,
            "completion_callback": {"method": "POST", "url": f"/client-llm-calls/{client_model_call_id}/complete"},
        }

    if execution_mode != "server":
        raise HTTPException(status_code=400, detail=f"Unsupported llm_execution.mode: {req.llm_execution.mode}")

    llm_resp = await post_json(f"{llm_url}/llm/respond", {
        "provider": provider,
        "model": model,
        "messages": compiled["messages"],
        "temperature": req.temperature,
        "max_tokens": req.max_output_tokens,
        "metadata": {**req.metadata, **scope, "session_id": req.session_id, "context_package_id": compiled["context_package_id"]},
    }, timeout=240.0)

    await post_json(f"{memory_url}/memory/messages", {
        "session_id": req.session_id,
        "capability_id": req.capability_id,
        "agent_id": req.agent_id,
        "role": "assistant",
        "content": llm_resp["response"],
        "provider": provider,
        "model_name": model,
    })

    await maybe_update_summary(req.session_id, req.capability_id, req.agent_id, force=False)

    opt = compiled["optimization"]
    metrics_run_id = None
    try:
        metrics = await post_json(f"{metrics_url}/metrics/token-savings", {
            "session_id": req.session_id,
            "capability_id": req.capability_id,
            "agent_id": req.agent_id,
            "context_package_id": compiled["context_package_id"],
            "model_call_id": llm_resp["model_call_id"],
            "optimization_mode": opt["mode"],
            "raw_input_tokens": opt["raw_input_tokens"],
            "optimized_input_tokens": opt["optimized_input_tokens"],
            "output_tokens": llm_resp.get("output_tokens", 0),
            "tokens_saved": opt["tokens_saved"],
            "percent_saved": opt["percent_saved"],
            "estimated_raw_cost": opt.get("estimated_raw_cost", 0.0),
            "estimated_optimized_cost": opt.get("estimated_optimized_cost", 0.0),
            "estimated_cost_saved": opt.get("estimated_cost_saved", 0.0),
            "provider": provider,
            "model_name": model,
            "latency_ms": llm_resp.get("latency_ms"),
        })
        metrics_run_id = metrics.get("id")
    except Exception:
        metrics_run_id = None

    return ChatRespondResponse(
        response=llm_resp["response"],
        session_id=req.session_id,
        capability_id=req.capability_id,
        agent_id=req.agent_id,
        agent_key=scope["agent_key"],
        agent_uid=scope["agent_uid"],
        context_package_id=compiled["context_package_id"],
        model_call_id=llm_resp["model_call_id"],
        optimization=opt,
        model_usage={"provider": llm_resp["provider"], "model": llm_resp["model"], "input_tokens": llm_resp["input_tokens"], "output_tokens": llm_resp["output_tokens"], "total_tokens": llm_resp["total_tokens"], "estimated_cost": llm_resp["estimated_cost"], "latency_ms": llm_resp["latency_ms"]},
        metrics_run_id=metrics_run_id,
    )


@app.post("/client-llm-calls/{client_model_call_id}/complete")
async def complete_client_llm_call(client_model_call_id: str, req: ClientLLMCompleteRequest):
    memory_url = settings.context_memory_url.rstrip("/")
    metrics_url = settings.metrics_ledger_url.rstrip("/")
    scope = scope_dict(req.capability_id, req.agent_id)

    await post_json(f"{memory_url}/memory/messages", {
        "session_id": req.session_id,
        "capability_id": req.capability_id,
        "agent_id": req.agent_id,
        "role": "assistant",
        "content": req.response_text,
        "provider": req.provider,
        "model_name": req.model,
    })

    mark_client_call_complete(client_model_call_id, req.model_dump())
    await maybe_update_summary(req.session_id, req.capability_id, req.agent_id, force=bool(req.metadata.get("force_summary", False)))
    await submit_learning_candidates(req)

    metrics_run_id = None
    opt = req.optimization or {}
    if opt:
        try:
            metrics = await post_json(f"{metrics_url}/metrics/token-savings", {
                "session_id": req.session_id,
                "capability_id": req.capability_id,
                "agent_id": req.agent_id,
                "context_package_id": req.context_package_id,
                "client_llm_call_id": client_model_call_id,
                "optimization_mode": opt.get("mode", "client_return_call"),
                "raw_input_tokens": opt.get("raw_input_tokens", 0),
                "optimized_input_tokens": opt.get("optimized_input_tokens", 0),
                "output_tokens": req.usage.get("output_tokens") or req.usage.get("completion_tokens") or 0,
                "tokens_saved": opt.get("tokens_saved", 0),
                "percent_saved": opt.get("percent_saved", 0.0),
                "estimated_raw_cost": opt.get("estimated_raw_cost", 0.0),
                "estimated_optimized_cost": opt.get("estimated_optimized_cost", 0.0),
                "estimated_cost_saved": opt.get("estimated_cost_saved", 0.0),
                "provider": req.provider,
                "model_name": req.model,
                "latency_ms": req.usage.get("latency_ms") or req.usage.get("latencyMs"),
            })
            metrics_run_id = metrics.get("id")
        except Exception:
            metrics_run_id = None

    return {"status": "saved", "client_model_call_id": client_model_call_id, "session_id": req.session_id, **scope, "context_package_id": req.context_package_id, "metrics_run_id": metrics_run_id, "message": "Client-executed LLM response stored in Context Fabric memory and summary pipeline triggered."}


@app.post("/client-llm-calls/{client_model_call_id}/fail")
async def fail_client_llm_call(client_model_call_id: str, payload: dict[str, Any]):
    error = payload.get("error") or payload.get("message") or "client LLM call failed"
    mark_client_call_failed(client_model_call_id, error, payload)
    return {"status": "failed_recorded", "client_model_call_id": client_model_call_id, "error": error}


class CompareRequest(BaseModel):
    session_id: str
    capability_id: str = "default-capability"
    agent_id: str = "default-agent"
    message: str
    modes: list[str] = Field(default_factory=lambda: ["none", "conservative", "medium", "aggressive"])
    max_context_tokens: int = 16000
    provider: str = "mock"
    model: str = "mock-fast"


@app.post("/context/compare")
async def context_compare(req: CompareRequest):
    runtime_profile = await fetch_runtime_profile(req.capability_id, req.agent_id)
    return await post_json(f"{settings.context_memory_url.rstrip('/')}/context/compare", {**req.model_dump(), "runtime_profile": runtime_profile})


@app.get("/metrics/dashboard")
async def metrics_dashboard():
    return await get_json(f"{settings.metrics_ledger_url.rstrip('/')}/metrics/dashboard")


@app.get("/sessions/{session_id}/metrics")
async def session_metrics(session_id: str):
    return await get_json(f"{settings.metrics_ledger_url.rstrip('/')}/metrics/savings/session/{session_id}")


@app.get("/sessions/{session_id}/messages")
async def session_messages(session_id: str, limit: int | None = None):
    suffix = f"?limit={limit}" if limit else ""
    return await get_json(f"{settings.context_memory_url.rstrip('/')}/memory/messages/{session_id}{suffix}")

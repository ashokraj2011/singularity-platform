from __future__ import annotations

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    llm_gateway_url: str = "http://localhost:8001"
    context_memory_url: str = "http://localhost:8002"
    metrics_ledger_url: str = "http://localhost:8003"
    agent_learning_service_url: str | None = None

    class Config:
        env_prefix = ""
        extra = "ignore"


settings = Settings()

from __future__ import annotations

import json
import os
import time
from contextlib import contextmanager
from typing import Any, Iterator

import psycopg
from psycopg.rows import dict_row


DEFAULT_DATABASE_URL = "postgresql://context_fabric:context_fabric@localhost:5432/context_fabric"


def database_url() -> str:
    # psycopg sync driver uses postgresql://, not postgresql+asyncpg://
    url = os.getenv("DATABASE_URL", DEFAULT_DATABASE_URL)
    return url.replace("postgresql+asyncpg://", "postgresql://")


@contextmanager
def pg_conn() -> Iterator[psycopg.Connection]:
    conn = psycopg.connect(database_url(), row_factory=dict_row)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def wait_for_postgres(max_attempts: int = 30, delay_seconds: float = 1.0) -> None:
    last_error: Exception | None = None
    for _ in range(max_attempts):
        try:
            with pg_conn() as conn:
                conn.execute("SELECT 1")
            return
        except Exception as exc:  # pragma: no cover - startup helper
            last_error = exc
            time.sleep(delay_seconds)
    raise RuntimeError(f"PostgreSQL unavailable after {max_attempts} attempts: {last_error}")


def json_dumps(value: Any) -> str:
    return json.dumps(value if value is not None else {}, ensure_ascii=False)


def fetch_all(sql: str, params: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    with pg_conn() as conn:
        rows = conn.execute(sql, params or {}).fetchall()
    return [dict(row) for row in rows]


def fetch_one(sql: str, params: dict[str, Any] | None = None) -> dict[str, Any] | None:
    with pg_conn() as conn:
        row = conn.execute(sql, params or {}).fetchone()
    return dict(row) if row else None


def execute_returning_id(sql: str, params: dict[str, Any]) -> str:
    with pg_conn() as conn:
        row = conn.execute(sql, params).fetchone()
    return str(row["id"])


def run_sql_script(sql: str) -> None:
    """Run a simple SQL script. Good enough for our init.sql (no procedural semicolon blocks)."""
    statements = [s.strip() for s in sql.split(";") if s.strip()]
    with pg_conn() as conn:
        for stmt in statements:
            conn.execute(stmt)

from __future__ import annotations

import hashlib


def normalize_identifier(value: str | None, default: str = "default") -> str:
    value = (value or default).strip().lower()
    return value or default


def build_agent_key(capability_id: str | None, agent_id: str | None) -> str:
    cap = normalize_identifier(capability_id, "default-capability")
    agent = normalize_identifier(agent_id, "default-agent")
    return f"{cap}:{agent}"


def build_agent_uid(capability_id: str | None, agent_id: str | None) -> str:
    key = build_agent_key(capability_id, agent_id)
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


def scope_dict(capability_id: str | None, agent_id: str | None) -> dict[str, str]:
    key = build_agent_key(capability_id, agent_id)
    return {
        "capability_id": normalize_identifier(capability_id, "default-capability"),
        "agent_id": normalize_identifier(agent_id, "default-agent"),
        "agent_key": key,
        "agent_uid": hashlib.sha256(key.encode("utf-8")).hexdigest(),
    }

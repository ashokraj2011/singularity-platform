
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE SCHEMA IF NOT EXISTS memory;
CREATE SCHEMA IF NOT EXISTS context;
CREATE SCHEMA IF NOT EXISTS llm;
CREATE SCHEMA IF NOT EXISTS metrics;
CREATE SCHEMA IF NOT EXISTS receipts;

CREATE TABLE IF NOT EXISTS memory.conversation_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_uid TEXT NOT NULL,
    agent_key TEXT NOT NULL,
    capability_id TEXT NOT NULL,
    agent_id TEXT NOT NULL,
    session_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    content_json JSONB,
    token_count INTEGER,
    provider TEXT,
    model_name TEXT,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_messages_session_time ON memory.conversation_messages (session_id, created_at);
CREATE INDEX IF NOT EXISTS idx_messages_agent_session ON memory.conversation_messages (agent_uid, session_id, created_at);
CREATE INDEX IF NOT EXISTS idx_messages_metadata_gin ON memory.conversation_messages USING GIN (metadata);

CREATE TABLE IF NOT EXISTS memory.context_summaries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_uid TEXT NOT NULL,
    agent_key TEXT NOT NULL,
    capability_id TEXT NOT NULL,
    agent_id TEXT NOT NULL,
    session_id TEXT NOT NULL,
    summary_type TEXT NOT NULL,
    version INTEGER NOT NULL,
    content JSONB NOT NULL,
    token_count INTEGER,
    embedding vector(1536),
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_summaries_scope ON memory.context_summaries (agent_uid, session_id, version DESC);
CREATE INDEX IF NOT EXISTS idx_summaries_content_gin ON memory.context_summaries USING GIN (content);

CREATE TABLE IF NOT EXISTS memory.memory_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_uid TEXT,
    agent_key TEXT,
    capability_id TEXT,
    agent_id TEXT,
    session_id TEXT,
    project_id TEXT,
    memory_type TEXT NOT NULL,
    content TEXT NOT NULL,
    content_json JSONB,
    importance_score NUMERIC(5,2) DEFAULT 0.50,
    confidence NUMERIC(5,2) DEFAULT 0.80,
    embedding vector(1536),
    source_type TEXT,
    source_id TEXT,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_memory_agent ON memory.memory_items (agent_uid, memory_type, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_memory_session ON memory.memory_items (session_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_memory_json_gin ON memory.memory_items USING GIN (content_json);

CREATE TABLE IF NOT EXISTS context.context_packages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_uid TEXT NOT NULL,
    agent_key TEXT NOT NULL,
    capability_id TEXT NOT NULL,
    agent_id TEXT NOT NULL,
    session_id TEXT NOT NULL,
    optimization_mode TEXT NOT NULL,
    compiled_context JSONB NOT NULL,
    included_sections JSONB NOT NULL DEFAULT '[]'::jsonb,
    raw_context_hash TEXT,
    optimized_context_hash TEXT,
    raw_input_tokens INTEGER NOT NULL,
    optimized_input_tokens INTEGER NOT NULL,
    tokens_saved INTEGER NOT NULL,
    percent_saved NUMERIC(6,2) NOT NULL,
    max_context_tokens INTEGER,
    agent_learning_profile_version INTEGER,
    runtime_profile_hash TEXT,
    runtime_profile JSONB NOT NULL DEFAULT '{}'::jsonb,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_context_packages_scope ON context.context_packages (agent_uid, session_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_context_packages_json_gin ON context.context_packages USING GIN (compiled_context);

CREATE TABLE IF NOT EXISTS llm.model_calls (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_uid TEXT,
    agent_key TEXT,
    capability_id TEXT,
    agent_id TEXT,
    session_id TEXT,
    context_package_id UUID,
    provider TEXT NOT NULL,
    model_name TEXT NOT NULL,
    request_json JSONB,
    response_json JSONB,
    input_tokens INTEGER,
    output_tokens INTEGER,
    total_tokens INTEGER,
    estimated_cost NUMERIC(12,6),
    latency_ms INTEGER,
    status TEXT NOT NULL,
    error TEXT,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_model_calls_scope ON llm.model_calls (agent_uid, session_id, created_at DESC);

CREATE TABLE IF NOT EXISTS llm.client_llm_calls (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_uid TEXT NOT NULL,
    agent_key TEXT NOT NULL,
    capability_id TEXT NOT NULL,
    agent_id TEXT NOT NULL,
    session_id TEXT NOT NULL,
    context_package_id UUID NOT NULL,
    provider TEXT NOT NULL,
    model_name TEXT NOT NULL,
    status TEXT NOT NULL,
    prepared_call_json JSONB NOT NULL,
    result_json JSONB,
    raw_input_tokens INTEGER,
    optimized_input_tokens INTEGER,
    output_tokens INTEGER,
    tokens_saved INTEGER,
    percent_saved NUMERIC(6,2),
    prepared_call_hash TEXT,
    result_hash TEXT,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at TIMESTAMPTZ,
    error TEXT
);
CREATE INDEX IF NOT EXISTS idx_client_llm_calls_scope ON llm.client_llm_calls (agent_uid, session_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_client_llm_calls_status ON llm.client_llm_calls (status);

CREATE TABLE IF NOT EXISTS metrics.token_savings_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_uid TEXT,
    agent_key TEXT,
    capability_id TEXT,
    agent_id TEXT,
    session_id TEXT NOT NULL,
    context_package_id UUID,
    model_call_id TEXT,
    client_llm_call_id TEXT,
    optimization_mode TEXT NOT NULL,
    raw_input_tokens INTEGER NOT NULL,
    optimized_input_tokens INTEGER NOT NULL,
    output_tokens INTEGER NOT NULL DEFAULT 0,
    tokens_saved INTEGER NOT NULL,
    percent_saved NUMERIC(6,2) NOT NULL,
    estimated_raw_cost NUMERIC(12,6) NOT NULL DEFAULT 0,
    estimated_optimized_cost NUMERIC(12,6) NOT NULL DEFAULT 0,
    estimated_cost_saved NUMERIC(12,6) NOT NULL DEFAULT 0,
    provider TEXT,
    model_name TEXT,
    latency_ms INTEGER,
    quality_score NUMERIC(5,2),
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_token_savings_scope ON metrics.token_savings_runs (agent_uid, session_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_token_savings_mode ON metrics.token_savings_runs (optimization_mode);

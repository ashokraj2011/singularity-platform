# Context Fabric Tool Gateway

A standalone Python/FastAPI service for **tool registration, discovery, prompt-card generation, validation, invocation, and execution receipts**.

This service does **not** own tool implementation. Clients own tool creation and implementation. The gateway only stores tool manifests and safely invokes external tool endpoints.

## Why this exists

Context Fabric should not hardcode every tool. Instead:

```text
Client-owned tools / MCP servers / internal APIs / AST tools
        |
        v
Context Fabric Tool Gateway
        |
        +-- register tool manifests
        +-- discover visible tools per agent/task
        +-- generate compact tool descriptions for LLM prompt
        +-- validate LLM tool requests
        +-- invoke external tool endpoint
        +-- store execution receipts
```

The LLM sees only the **visible tool set** for the current agent run, not the universal registry.

## Run

```bash
cp .env.example .env
pip install -r requirements.txt
uvicorn services.tool_gateway_service.app.main:app --host 0.0.0.0 --port 8010 --reload
```

Or Docker:

```bash
docker compose up --build
```

Open:

```text
http://localhost:8010/docs
```

## Core endpoints

```text
POST /tools/register       Register or update a tool manifest
GET  /tools                List registered tools
POST /tools/discover       Return relevant visible tools for an agent/task
POST /tools/cards          Return compact LLM-facing tool cards
POST /tools/invoke         Validate and invoke an external tool endpoint
GET  /tools/executions/{id} Read invocation receipt
```

## Tool manifest

A tool is described by:

```json
{
  "tool_name": "code.search",
  "description": "AST-aware code search. Prefer over grep for code questions.",
  "input_schema": {
    "type": "object",
    "properties": {
      "query": { "type": "string" },
      "path": { "type": "string" },
      "limit": { "type": "integer" }
    },
    "required": ["query"]
  },
  "endpoint": {
    "type": "http",
    "url": "http://localhost:8020/tools/code.search",
    "method": "POST"
  },
  "risk_level": "low",
  "requires_approval": false,
  "allowed_agents": ["developer-agent", "architect-agent"],
  "tags": ["code", "ast", "repo", "search"],
  "enabled": true
}
```

## Register example AST tools

Terminal 1:

```bash
uvicorn services.tool_gateway_service.app.main:app --host 0.0.0.0 --port 8010 --reload
```

Terminal 2:

```bash
uvicorn examples.external_ast_tool_server:app --host 0.0.0.0 --port 8020 --reload
```

Terminal 3:

```bash
./examples/register_ast_tools.sh
```

## Discover tools

```bash
curl -s http://localhost:8010/tools/discover \
  -H 'Content-Type: application/json' \
  -d '{
    "agent_id":"developer-agent",
    "query":"Where is token saving calculated in code?",
    "task_type":"code_question",
    "risk_max":"medium",
    "limit":5
  }' | jq
```

## Generate LLM tool cards

```bash
curl -s http://localhost:8010/tools/cards \
  -H 'Content-Type: application/json' \
  -d '{
    "agent_id":"developer-agent",
    "query":"Where is token saving calculated in code?",
    "task_type":"code_question",
    "risk_max":"medium",
    "limit":5,
    "format":"text"
  }' | jq -r .tool_cards_text
```

Inject that text into the model prompt. The model can then return:

```json
{
  "response_type": "tool_request",
  "tool_calls": [
    {
      "tool_name": "code.search",
      "arguments": {"query": "compile_context", "limit": 5},
      "reason": "Need to find where context/token saving is implemented."
    }
  ]
}
```

## Invoke a tool

```bash
curl -s http://localhost:8010/tools/invoke \
  -H 'Content-Type: application/json' \
  -d '{
    "session_id":"demo-session",
    "agent_id":"developer-agent",
    "tool_name":"code.search",
    "arguments": {"query":"compile_context", "limit": 5}
  }' | jq
```

## Design rule

The LLM never owns execution.

```text
LLM requests tool -> Gateway validates -> External tool runs -> Gateway stores receipt -> result goes back to LLM
```

Tool creation, AST indexers, code search, API calls, and proprietary enterprise integrations stay outside the gateway and are owned by clients.

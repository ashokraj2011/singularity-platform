from fastapi.testclient import TestClient
from services.tool_gateway_service.app.main import app

client = TestClient(app)


def test_register_and_discover_tool():
    payload = {
        "tool_name": "code.search",
        "version": "1.0",
        "description": "AST-aware code search. Prefer over grep for code questions.",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
        "endpoint": {"type": "http", "url": "http://localhost:8020/tools/code.search", "method": "POST"},
        "risk_level": "low",
        "requires_approval": False,
        "allowed_agents": ["developer-agent"],
        "tags": ["code", "ast", "repo", "search"],
        "enabled": True,
    }
    r = client.post("/tools/register", json=payload)
    assert r.status_code == 200, r.text

    r = client.post("/tools/discover", json={
        "agent_id": "developer-agent",
        "query": "find function compile_context",
        "task_type": "code_question",
        "risk_max": "medium",
    })
    assert r.status_code == 200, r.text
    tools = r.json()["tools"]
    assert any(t["tool_name"] == "code.search" for t in tools)


def test_disallowed_agent_cannot_discover_tool():
    r = client.post("/tools/discover", json={
        "agent_id": "governance-agent",
        "query": "find function compile_context",
        "risk_max": "medium",
    })
    assert r.status_code == 200, r.text
    tools = r.json()["tools"]
    assert not any(t["tool_name"] == "code.search" for t in tools)

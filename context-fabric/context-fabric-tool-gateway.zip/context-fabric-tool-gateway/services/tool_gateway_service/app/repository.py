import json
import uuid
from datetime import datetime, timezone
from typing import Any
from .db import sqlite_conn
from .schemas import ToolDefinitionIn, ToolDefinitionOut


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def row_to_tool(row) -> ToolDefinitionOut:
    return ToolDefinitionOut(
        id=row["id"],
        tool_name=row["tool_name"],
        version=row["version"],
        description=row["description"],
        input_schema=json.loads(row["input_schema_json"]),
        output_schema=json.loads(row["output_schema_json"]) if row["output_schema_json"] else None,
        endpoint=json.loads(row["endpoint_json"]),
        risk_level=row["risk_level"],
        requires_approval=bool(row["requires_approval"]),
        allowed_agents=json.loads(row["allowed_agents_json"]),
        tags=json.loads(row["tags_json"]),
        enabled=bool(row["enabled"]),
        created_at=row["created_at"],
        updated_at=row["updated_at"],
    )


def upsert_tool(data: ToolDefinitionIn) -> ToolDefinitionOut:
    existing = get_tool(data.tool_name)
    ts = now_iso()
    if existing:
        with sqlite_conn() as conn:
            conn.execute(
                """
                UPDATE tool_definitions
                SET version=?, description=?, input_schema_json=?, output_schema_json=?, endpoint_json=?,
                    risk_level=?, requires_approval=?, allowed_agents_json=?, tags_json=?, enabled=?, updated_at=?
                WHERE tool_name=?
                """,
                (
                    data.version,
                    data.description,
                    json.dumps(data.input_schema),
                    json.dumps(data.output_schema) if data.output_schema is not None else None,
                    data.endpoint.model_dump_json(),
                    data.risk_level,
                    int(data.requires_approval),
                    json.dumps(data.allowed_agents),
                    json.dumps(data.tags),
                    int(data.enabled),
                    ts,
                    data.tool_name,
                ),
            )
        return get_tool(data.tool_name)  # type: ignore[return-value]

    tool_id = str(uuid.uuid4())
    with sqlite_conn() as conn:
        conn.execute(
            """
            INSERT INTO tool_definitions
            (id, tool_name, version, description, input_schema_json, output_schema_json, endpoint_json,
             risk_level, requires_approval, allowed_agents_json, tags_json, enabled, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                tool_id,
                data.tool_name,
                data.version,
                data.description,
                json.dumps(data.input_schema),
                json.dumps(data.output_schema) if data.output_schema is not None else None,
                data.endpoint.model_dump_json(),
                data.risk_level,
                int(data.requires_approval),
                json.dumps(data.allowed_agents),
                json.dumps(data.tags),
                int(data.enabled),
                ts,
                ts,
            ),
        )
    return get_tool(data.tool_name)  # type: ignore[return-value]


def get_tool(tool_name: str) -> ToolDefinitionOut | None:
    with sqlite_conn() as conn:
        row = conn.execute("SELECT * FROM tool_definitions WHERE tool_name=?", (tool_name,)).fetchone()
    return row_to_tool(row) if row else None


def list_tools(include_disabled: bool = False) -> list[ToolDefinitionOut]:
    with sqlite_conn() as conn:
        if include_disabled:
            rows = conn.execute("SELECT * FROM tool_definitions ORDER BY tool_name").fetchall()
        else:
            rows = conn.execute("SELECT * FROM tool_definitions WHERE enabled=1 ORDER BY tool_name").fetchall()
    return [row_to_tool(r) for r in rows]


def insert_execution(data: dict[str, Any]) -> str:
    exec_id = str(uuid.uuid4())
    with sqlite_conn() as conn:
        conn.execute(
            """
            INSERT INTO tool_executions
            (id, session_id, agent_id, tool_name, arguments_json, output_json, output_summary,
             status, error, risk_level, requires_approval, approval_id, context_package_id, model_call_id,
             latency_ms, started_at, completed_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                exec_id,
                data.get("session_id"),
                data.get("agent_id"),
                data["tool_name"],
                json.dumps(data.get("arguments", {})),
                json.dumps(data.get("output")) if data.get("output") is not None else None,
                data.get("output_summary"),
                data["status"],
                data.get("error"),
                data.get("risk_level"),
                int(data.get("requires_approval", False)) if data.get("requires_approval") is not None else None,
                data.get("approval_id"),
                data.get("context_package_id"),
                data.get("model_call_id"),
                data.get("latency_ms"),
                data.get("started_at") or now_iso(),
                data.get("completed_at"),
            ),
        )
    return exec_id


def get_execution(exec_id: str) -> dict[str, Any] | None:
    with sqlite_conn() as conn:
        row = conn.execute("SELECT * FROM tool_executions WHERE id=?", (exec_id,)).fetchone()
    if not row:
        return None
    return {
        "id": row["id"],
        "session_id": row["session_id"],
        "agent_id": row["agent_id"],
        "tool_name": row["tool_name"],
        "arguments": json.loads(row["arguments_json"]),
        "output": json.loads(row["output_json"]) if row["output_json"] else None,
        "output_summary": row["output_summary"],
        "status": row["status"],
        "error": row["error"],
        "risk_level": row["risk_level"],
        "requires_approval": bool(row["requires_approval"]) if row["requires_approval"] is not None else None,
        "approval_id": row["approval_id"],
        "context_package_id": row["context_package_id"],
        "model_call_id": row["model_call_id"],
        "latency_ms": row["latency_ms"],
        "started_at": row["started_at"],
        "completed_at": row["completed_at"],
    }

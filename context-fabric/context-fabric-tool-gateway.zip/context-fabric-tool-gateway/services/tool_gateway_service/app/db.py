import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from .config import settings


def ensure_parent(path: str) -> None:
    parent = Path(path).parent
    parent.mkdir(parents=True, exist_ok=True)


@contextmanager
def sqlite_conn(path: str | None = None):
    db_path = path or settings.db_path
    ensure_parent(db_path)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with sqlite_conn() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS tool_definitions (
                id TEXT PRIMARY KEY,
                tool_name TEXT NOT NULL UNIQUE,
                version TEXT NOT NULL,
                description TEXT NOT NULL,
                input_schema_json TEXT NOT NULL,
                output_schema_json TEXT,
                endpoint_json TEXT NOT NULL,
                risk_level TEXT NOT NULL,
                requires_approval INTEGER NOT NULL DEFAULT 0,
                allowed_agents_json TEXT NOT NULL,
                tags_json TEXT NOT NULL,
                enabled INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS tool_executions (
                id TEXT PRIMARY KEY,
                session_id TEXT,
                agent_id TEXT,
                tool_name TEXT NOT NULL,
                arguments_json TEXT NOT NULL,
                output_json TEXT,
                output_summary TEXT,
                status TEXT NOT NULL,
                error TEXT,
                risk_level TEXT,
                requires_approval INTEGER,
                approval_id TEXT,
                context_package_id TEXT,
                model_call_id TEXT,
                latency_ms INTEGER,
                started_at TEXT NOT NULL,
                completed_at TEXT
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_tool_executions_session ON tool_executions(session_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_tool_definitions_name ON tool_definitions(tool_name)")

import re
from .schemas import ToolDefinitionOut, ToolCard, ToolDiscoverRequest
from .policy import is_agent_allowed, risk_allowed


def tokenize(text: str | None) -> set[str]:
    if not text:
        return set()
    return set(re.findall(r"[a-zA-Z0-9_./:-]+", text.lower()))


def score_tool(tool: ToolDefinitionOut, query: str | None, task_type: str | None, tags: list[str]) -> float:
    q_tokens = tokenize(query) | tokenize(task_type) | set(t.lower() for t in tags)
    if not q_tokens:
        return 0.1

    tool_tokens = (
        tokenize(tool.tool_name)
        | tokenize(tool.description)
        | set(t.lower() for t in tool.tags)
    )
    overlap = len(q_tokens & tool_tokens)
    score = float(overlap)

    # Prefer AST/code tools for code-oriented queries.
    code_terms = {"code", "function", "class", "method", "symbol", "route", "ast", "repo", "file", "implementation"}
    if q_tokens & code_terms and any(t in {"code", "ast", "repo"} for t in [x.lower() for x in tool.tags]):
        score += 1.5

    # Prefer metrics tools for token/cost questions.
    metric_terms = {"token", "tokens", "saving", "savings", "cost", "metrics"}
    if q_tokens & metric_terms and any(t in {"metrics", "token", "context"} for t in [x.lower() for x in tool.tags]):
        score += 1.0

    return score


def discover_tools(tools: list[ToolDefinitionOut], req: ToolDiscoverRequest) -> list[ToolCard]:
    cards: list[ToolCard] = []
    for tool in tools:
        if not req.include_disabled and not tool.enabled:
            continue
        if not is_agent_allowed(tool, req.agent_id):
            continue
        if not risk_allowed(tool, req.risk_max):
            continue
        if req.tags:
            tool_tags = set(t.lower() for t in tool.tags)
            if not set(t.lower() for t in req.tags) & tool_tags:
                continue
        score = score_tool(tool, req.query, req.task_type, req.tags)
        cards.append(
            ToolCard(
                tool_name=tool.tool_name,
                description=tool.description,
                input_schema=tool.input_schema,
                risk_level=tool.risk_level,
                requires_approval=tool.requires_approval,
                tags=tool.tags,
                score=round(score, 4),
            )
        )
    cards.sort(key=lambda c: c.score, reverse=True)
    return cards[: max(1, req.limit)]

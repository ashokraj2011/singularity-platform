from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    db_path: str = "./data/tool_gateway/tool_gateway.db"
    host: str = "0.0.0.0"
    port: int = 8010
    default_timeout_seconds: int = 30
    max_response_chars: int = 20000

    class Config:
        env_prefix = "TOOL_GATEWAY_"
        env_file = ".env"
        extra = "ignore"


settings = Settings()

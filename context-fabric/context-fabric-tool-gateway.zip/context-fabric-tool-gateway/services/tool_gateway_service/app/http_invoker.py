import os
import time
from datetime import datetime, timezone
from typing import Any
import httpx
from jsonschema import validate, ValidationError
from .config import settings
from .schemas import ToolDefinitionOut, ToolInvokeRequest
from .repository import insert_execution


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def build_headers(tool: ToolDefinitionOut) -> dict[str, str]:
    headers = dict(tool.endpoint.headers or {})
    for header_name, env_var in (tool.endpoint.header_env or {}).items():
        value = os.getenv(env_var)
        if value:
            headers[header_name] = value
    return headers


def summarize_output(output: Any, max_chars: int | None = None) -> str:
    max_len = max_chars or settings.max_response_chars
    text = str(output)
    if len(text) <= max_len:
        return text
    return text[:max_len] + f"\n...[truncated {len(text) - max_len} chars]"


async def invoke_http_tool(tool: ToolDefinitionOut, req: ToolInvokeRequest) -> dict[str, Any]:
    started = now_iso()
    t0 = time.perf_counter()

    try:
        validate(instance=req.arguments, schema=tool.input_schema)
    except ValidationError as e:
        completed = now_iso()
        latency_ms = int((time.perf_counter() - t0) * 1000)
        exec_id = insert_execution({
            "session_id": req.session_id,
            "agent_id": req.agent_id,
            "tool_name": req.tool_name,
            "arguments": req.arguments,
            "status": "blocked",
            "error": f"Invalid tool arguments: {e.message}",
            "risk_level": tool.risk_level,
            "requires_approval": tool.requires_approval,
            "approval_id": req.approval_id,
            "context_package_id": req.context_package_id,
            "model_call_id": req.model_call_id,
            "latency_ms": latency_ms,
            "started_at": started,
            "completed_at": completed,
        })
        return {
            "tool_execution_id": exec_id,
            "tool_name": tool.tool_name,
            "status": "blocked",
            "error": f"Invalid tool arguments: {e.message}",
            "latency_ms": latency_ms,
            "requires_approval": tool.requires_approval,
            "risk_level": tool.risk_level,
        }

    timeout = tool.endpoint.timeout_seconds or settings.default_timeout_seconds
    headers = build_headers(tool)
    payload = {
        "tool_name": tool.tool_name,
        "arguments": req.arguments,
        "session_id": req.session_id,
        "agent_id": req.agent_id,
        "metadata": req.metadata,
    }

    status = "success"
    output = None
    error = None

    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            if tool.endpoint.method == "GET":
                resp = await client.get(tool.endpoint.url, params=req.arguments, headers=headers)
            else:
                resp = await client.post(tool.endpoint.url, json=payload, headers=headers)
            resp.raise_for_status()
            content_type = resp.headers.get("content-type", "")
            output = resp.json() if "application/json" in content_type else {"text": resp.text}
    except Exception as e:
        status = "failed"
        error = str(e)

    completed = now_iso()
    latency_ms = int((time.perf_counter() - t0) * 1000)
    summary = summarize_output(output if output is not None else error)

    exec_id = insert_execution({
        "session_id": req.session_id,
        "agent_id": req.agent_id,
        "tool_name": req.tool_name,
        "arguments": req.arguments,
        "output": output,
        "output_summary": summary,
        "status": status,
        "error": error,
        "risk_level": tool.risk_level,
        "requires_approval": tool.requires_approval,
        "approval_id": req.approval_id,
        "context_package_id": req.context_package_id,
        "model_call_id": req.model_call_id,
        "latency_ms": latency_ms,
        "started_at": started,
        "completed_at": completed,
    })

    return {
        "tool_execution_id": exec_id,
        "tool_name": tool.tool_name,
        "status": status,
        "output": output,
        "summary": summary,
        "error": error,
        "latency_ms": latency_ms,
        "requires_approval": tool.requires_approval,
        "risk_level": tool.risk_level,
    }

from typing import Any, Literal
from pydantic import BaseModel, Field, HttpUrl

RiskLevel = Literal["low", "medium", "high", "critical"]
EndpointType = Literal["http"]


class HttpEndpoint(BaseModel):
    type: EndpointType = "http"
    url: str = Field(..., description="External tool HTTP endpoint URL.")
    method: Literal["POST", "GET"] = "POST"
    headers: dict[str, str] = Field(default_factory=dict, description="Static headers. Avoid secrets here.")
    header_env: dict[str, str] = Field(
        default_factory=dict,
        description="Map header name to environment variable name. Example: {'Authorization': 'AST_TOOL_AUTH'}",
    )
    timeout_seconds: int | None = None


class ToolDefinitionIn(BaseModel):
    tool_name: str
    version: str = "1.0"
    description: str
    input_schema: dict[str, Any]
    output_schema: dict[str, Any] | None = None
    endpoint: HttpEndpoint
    risk_level: RiskLevel = "low"
    requires_approval: bool = False
    allowed_agents: list[str] = Field(default_factory=lambda: ["*"])
    tags: list[str] = Field(default_factory=list)
    enabled: bool = True


class ToolDefinitionOut(ToolDefinitionIn):
    id: str
    created_at: str
    updated_at: str


class ToolDiscoverRequest(BaseModel):
    agent_id: str | None = None
    query: str | None = None
    task_type: str | None = None
    tags: list[str] = Field(default_factory=list)
    risk_max: RiskLevel = "medium"
    limit: int = 8
    include_disabled: bool = False


class ToolCard(BaseModel):
    tool_name: str
    description: str
    input_schema: dict[str, Any]
    risk_level: RiskLevel
    requires_approval: bool
    tags: list[str]
    score: float = 0.0


class ToolDiscoverResponse(BaseModel):
    tools: list[ToolCard]


class ToolCardsRequest(ToolDiscoverRequest):
    format: Literal["text", "json"] = "text"


class ToolCardsResponse(BaseModel):
    tool_cards_text: str | None = None
    tool_cards: list[ToolCard] | None = None


class ToolInvokeRequest(BaseModel):
    session_id: str | None = None
    agent_id: str | None = None
    tool_name: str
    arguments: dict[str, Any]
    context_package_id: str | None = None
    model_call_id: str | None = None
    approval_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ToolInvokeResponse(BaseModel):
    tool_execution_id: str
    tool_name: str
    status: Literal["success", "failed", "blocked", "approval_required"]
    output: Any | None = None
    summary: str | None = None
    error: str | None = None
    latency_ms: int | None = None
    requires_approval: bool = False
    risk_level: RiskLevel | None = None


class ToolExecutionOut(BaseModel):
    id: str
    session_id: str | None
    agent_id: str | None
    tool_name: str
    arguments: dict[str, Any]
    output: Any | None
    output_summary: str | None
    status: str
    error: str | None
    risk_level: str | None
    requires_approval: bool | None
    approval_id: str | None
    context_package_id: str | None
    model_call_id: str | None
    latency_ms: int | None
    started_at: str
    completed_at: str | None

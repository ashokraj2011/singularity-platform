import json
from .schemas import ToolCard


def render_tool_cards_text(cards: list[ToolCard]) -> str:
    if not cards:
        return "No tools are available for this request."

    blocks = [
        "You can request tools, but you cannot execute them directly.",
        "Only request tools listed below. Return strict JSON when you need a tool.",
        "",
        "Tool request format:",
        json.dumps({
            "response_type": "tool_request",
            "tool_calls": [
                {
                    "tool_name": "tool.name",
                    "arguments": {},
                    "reason": "why this tool is needed"
                }
            ]
        }, indent=2),
        "",
        "Final answer format:",
        json.dumps({"response_type": "final_answer", "answer": "..."}, indent=2),
        "",
        "Available tools:",
    ]

    for card in cards:
        blocks.append(f"\nTool: {card.tool_name}")
        blocks.append(f"Description: {card.description}")
        blocks.append(f"Risk: {card.risk_level}; requires_approval={card.requires_approval}")
        if card.tags:
            blocks.append(f"Tags: {', '.join(card.tags)}")
        blocks.append("Input schema:")
        blocks.append(json.dumps(card.input_schema, indent=2))

    return "\n".join(blocks)

from fastapi import FastAPI, HTTPException
from .db import init_db
from .schemas import (
    ToolDefinitionIn,
    ToolDefinitionOut,
    ToolDiscoverRequest,
    ToolDiscoverResponse,
    ToolCardsRequest,
    ToolCardsResponse,
    ToolInvokeRequest,
    ToolInvokeResponse,
    ToolExecutionOut,
)
from .repository import upsert_tool, get_tool, list_tools, get_execution, insert_execution, now_iso
from .tool_selector import discover_tools
from .prompt_cards import render_tool_cards_text
from .policy import validate_execution_policy
from .http_invoker import invoke_http_tool

app = FastAPI(title="Context Fabric Tool Gateway", version="0.1.0")


@app.on_event("startup")
def startup():
    init_db()


@app.get("/health")
def health():
    return {"status": "ok", "service": "tool-gateway-service"}


@app.post("/tools/register", response_model=ToolDefinitionOut)
def register_tool(tool: ToolDefinitionIn):
    return upsert_tool(tool)


@app.get("/tools", response_model=list[ToolDefinitionOut])
def list_registered_tools(include_disabled: bool = False):
    return list_tools(include_disabled=include_disabled)


@app.get("/tools/{tool_name}", response_model=ToolDefinitionOut)
def get_registered_tool(tool_name: str):
    tool = get_tool(tool_name)
    if not tool:
        raise HTTPException(status_code=404, detail=f"Tool not found: {tool_name}")
    return tool


@app.post("/tools/discover", response_model=ToolDiscoverResponse)
def discover(req: ToolDiscoverRequest):
    tools = list_tools(include_disabled=req.include_disabled)
    cards = discover_tools(tools, req)
    return ToolDiscoverResponse(tools=cards)


@app.post("/tools/cards", response_model=ToolCardsResponse)
def tool_cards(req: ToolCardsRequest):
    tools = list_tools(include_disabled=req.include_disabled)
    cards = discover_tools(tools, req)
    if req.format == "json":
        return ToolCardsResponse(tool_cards=cards)
    return ToolCardsResponse(tool_cards_text=render_tool_cards_text(cards))


@app.post("/tools/invoke", response_model=ToolInvokeResponse)
async def invoke(req: ToolInvokeRequest):
    tool = get_tool(req.tool_name)
    if not tool:
        exec_id = insert_execution({
            "session_id": req.session_id,
            "agent_id": req.agent_id,
            "tool_name": req.tool_name,
            "arguments": req.arguments,
            "status": "blocked",
            "error": f"Unknown tool: {req.tool_name}",
            "started_at": now_iso(),
            "completed_at": now_iso(),
        })
        return ToolInvokeResponse(
            tool_execution_id=exec_id,
            tool_name=req.tool_name,
            status="blocked",
            error=f"Unknown tool: {req.tool_name}",
        )

    allowed, reason, status = validate_execution_policy(tool, req.agent_id, req.approval_id)
    if not allowed:
        exec_id = insert_execution({
            "session_id": req.session_id,
            "agent_id": req.agent_id,
            "tool_name": req.tool_name,
            "arguments": req.arguments,
            "status": status,
            "error": reason,
            "risk_level": tool.risk_level,
            "requires_approval": tool.requires_approval,
            "approval_id": req.approval_id,
            "context_package_id": req.context_package_id,
            "model_call_id": req.model_call_id,
            "started_at": now_iso(),
            "completed_at": now_iso(),
        })
        return ToolInvokeResponse(
            tool_execution_id=exec_id,
            tool_name=req.tool_name,
            status=status,  # type: ignore[arg-type]
            error=reason,
            requires_approval=tool.requires_approval,
            risk_level=tool.risk_level,
        )

    result = await invoke_http_tool(tool, req)
    return ToolInvokeResponse(**result)


@app.get("/tools/executions/{execution_id}", response_model=ToolExecutionOut)
def read_execution(execution_id: str):
    execution = get_execution(execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail=f"Tool execution not found: {execution_id}")
    return ToolExecutionOut(**execution)

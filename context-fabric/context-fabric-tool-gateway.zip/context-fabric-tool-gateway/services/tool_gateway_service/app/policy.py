from .schemas import ToolDefinitionOut

RISK_ORDER = {
    "low": 1,
    "medium": 2,
    "high": 3,
    "critical": 4,
}


def is_agent_allowed(tool: ToolDefinitionOut, agent_id: str | None) -> bool:
    allowed = tool.allowed_agents or []
    if "*" in allowed:
        return True
    if not agent_id:
        return False
    return agent_id in allowed


def risk_allowed(tool: ToolDefinitionOut, risk_max: str) -> bool:
    return RISK_ORDER.get(tool.risk_level, 99) <= RISK_ORDER.get(risk_max, 2)


def validate_execution_policy(tool: ToolDefinitionOut, agent_id: str | None, approval_id: str | None) -> tuple[bool, str | None, str]:
    if not tool.enabled:
        return False, "Tool is disabled.", "blocked"

    if not is_agent_allowed(tool, agent_id):
        return False, f"Agent {agent_id or '<none>'} is not allowed to use {tool.tool_name}.", "blocked"

    if tool.requires_approval and not approval_id:
        return False, f"Tool {tool.tool_name} requires approval.", "approval_required"

    return True, None, "allowed"

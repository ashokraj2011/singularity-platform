#!/usr/bin/env bash
set -euo pipefail
GATEWAY_URL="${GATEWAY_URL:-http://localhost:8010}"
AST_SERVER_URL="${AST_SERVER_URL:-http://localhost:8020}"

curl -s "$GATEWAY_URL/tools/register" \
  -H 'Content-Type: application/json' \
  -d "{
    \"tool_name\": \"code.search\",
    \"version\": \"1.0\",
    \"description\": \"AST-aware code search. Use for functions, classes, methods, routes, symbols, and implementation logic. Prefer over grep for code questions.\",
    \"input_schema\": {
      \"type\": \"object\",
      \"properties\": {
        \"query\": {\"type\": \"string\"},
        \"path\": {\"type\": \"string\"},
        \"limit\": {\"type\": \"integer\"}
      },
      \"required\": [\"query\"]
    },
    \"endpoint\": {\"type\": \"http\", \"url\": \"$AST_SERVER_URL/tools/code.search\", \"method\": \"POST\"},
    \"risk_level\": \"low\",
    \"requires_approval\": false,
    \"allowed_agents\": [\"developer-agent\", \"architect-agent\", \"*\"],
    \"tags\": [\"code\", \"ast\", \"repo\", \"search\"],
    \"enabled\": true
  }" | jq

curl -s "$GATEWAY_URL/tools/register" \
  -H 'Content-Type: application/json' \
  -d "{
    \"tool_name\": \"code.read_symbol\",
    \"version\": \"1.0\",
    \"description\": \"Reads the exact source for an indexed symbol returned by code.search.\",
    \"input_schema\": {
      \"type\": \"object\",
      \"properties\": {
        \"symbol_id\": {\"type\": \"string\"}
      },
      \"required\": [\"symbol_id\"]
    },
    \"endpoint\": {\"type\": \"http\", \"url\": \"$AST_SERVER_URL/tools/code.read_symbol\", \"method\": \"POST\"},
    \"risk_level\": \"low\",
    \"requires_approval\": false,
    \"allowed_agents\": [\"developer-agent\", \"architect-agent\", \"*\"],
    \"tags\": [\"code\", \"ast\", \"symbol\", \"read\"],
    \"enabled\": true
  }" | jq

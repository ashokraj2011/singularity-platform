"""
Example external client-owned tool server.

This is NOT part of the Tool Gateway core. It shows how a client can implement
AST-aware tools and register them with Context Fabric Tool Gateway.

Run:
  uvicorn examples.external_ast_tool_server:app --host 0.0.0.0 --port 8020 --reload

Then register tools using examples/register_ast_tools.sh.
"""
import ast
from pathlib import Path
from typing import Any
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI(title="Example AST Tool Server", version="0.1.0")

# Keep this configurable in a real client implementation.
WORKSPACE = Path(__file__).resolve().parents[1]


class ToolRequest(BaseModel):
    tool_name: str
    arguments: dict[str, Any]
    session_id: str | None = None
    agent_id: str | None = None
    metadata: dict[str, Any] = {}


def safe_path(path: str | None = None) -> Path:
    base = WORKSPACE
    target = (base / (path or ".")).resolve()
    if not str(target).startswith(str(base.resolve())):
        raise HTTPException(status_code=400, detail="Path escapes workspace")
    return target


def extract_symbols(file_path: Path) -> list[dict[str, Any]]:
    content = file_path.read_text(encoding="utf-8", errors="ignore")
    try:
        tree = ast.parse(content)
    except SyntaxError:
        return []
    lines = content.splitlines()
    rel = str(file_path.relative_to(WORKSPACE))
    symbols: list[dict[str, Any]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            end_line = getattr(node, "end_lineno", node.lineno)
            symbols.append({
                "symbol_id": f"{rel}:{node.name}:{node.lineno}",
                "symbol_name": node.name,
                "symbol_type": "class",
                "file_path": rel,
                "start_line": node.lineno,
                "end_line": end_line,
                "signature": f"class {node.name}",
                "docstring": ast.get_docstring(node),
                "source_preview": "\n".join(lines[node.lineno - 1: min(end_line, node.lineno + 12)]),
            })
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            end_line = getattr(node, "end_lineno", node.lineno)
            args = [a.arg for a in node.args.args]
            prefix = "async def" if isinstance(node, ast.AsyncFunctionDef) else "def"
            symbols.append({
                "symbol_id": f"{rel}:{node.name}:{node.lineno}",
                "symbol_name": node.name,
                "symbol_type": "async_function" if isinstance(node, ast.AsyncFunctionDef) else "function",
                "file_path": rel,
                "start_line": node.lineno,
                "end_line": end_line,
                "signature": f"{prefix} {node.name}({', '.join(args)})",
                "docstring": ast.get_docstring(node),
                "source_preview": "\n".join(lines[node.lineno - 1: min(end_line, node.lineno + 12)]),
            })
    return symbols


def score(query: str, symbol: dict[str, Any]) -> float:
    q = query.lower()
    s = 0.0
    if q == symbol["symbol_name"].lower():
        s += 5.0
    if q in symbol["symbol_name"].lower():
        s += 3.0
    if q in symbol["file_path"].lower():
        s += 1.5
    if q in (symbol.get("signature") or "").lower():
        s += 1.0
    if q in (symbol.get("docstring") or "").lower():
        s += 1.0
    if q in (symbol.get("source_preview") or "").lower():
        s += 0.5
    return s


@app.post("/tools/code.search")
def code_search(req: ToolRequest):
    query = str(req.arguments.get("query", "")).strip()
    path = req.arguments.get("path") or "."
    limit = int(req.arguments.get("limit") or 10)
    if not query:
        raise HTTPException(status_code=400, detail="query is required")

    root = safe_path(path)
    files = [root] if root.is_file() else list(root.rglob("*.py"))
    results: list[dict[str, Any]] = []
    for file in files:
        if ".venv" in file.parts or "__pycache__" in file.parts:
            continue
        for sym in extract_symbols(file):
            sym_score = score(query, sym)
            if sym_score > 0:
                sym["score"] = sym_score
                results.append(sym)
    results.sort(key=lambda x: x["score"], reverse=True)
    return {"status": "success", "results": results[:limit]}


@app.post("/tools/code.read_symbol")
def read_symbol(req: ToolRequest):
    symbol_id = str(req.arguments.get("symbol_id", ""))
    if not symbol_id:
        raise HTTPException(status_code=400, detail="symbol_id is required")
    parts = symbol_id.split(":")
    if len(parts) < 3:
        raise HTTPException(status_code=400, detail="symbol_id format must be file:name:line")
    rel_file, symbol_name, line_s = parts[0], parts[1], parts[2]
    file_path = safe_path(rel_file)
    for sym in extract_symbols(file_path):
        if sym["symbol_name"] == symbol_name and str(sym["start_line"]) == line_s:
            content = file_path.read_text(encoding="utf-8", errors="ignore")
            lines = content.splitlines()
            source = "\n".join(lines[sym["start_line"] - 1:sym["end_line"]])
            return {"status": "success", "symbol": {**sym, "source": source}}
    raise HTTPException(status_code=404, detail="symbol not found")

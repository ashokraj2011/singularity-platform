from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import httpx


@dataclass
class ContextFabricClient:
    base_url: str = "http://localhost:8000"
    timeout: float = 240.0

    def respond(self, session_id: str, message: str, agent_id: str = "default-agent",
                provider: str = "mock", model: str = "mock-fast",
                optimization_mode: str = "medium", compare_with_raw: bool = True,
                max_context_tokens: int = 16000, **kwargs: Any) -> dict:
        payload = {
            "session_id": session_id,
            "agent_id": agent_id,
            "message": message,
            "provider": provider,
            "model": model,
            "context_policy": {
                "optimization_mode": optimization_mode,
                "compare_with_raw": compare_with_raw,
                "max_context_tokens": max_context_tokens,
            },
            **kwargs,
        }
        with httpx.Client(timeout=self.timeout) as client:
            resp = client.post(self.base_url.rstrip("/") + "/chat/respond", json=payload)
            resp.raise_for_status()
            return resp.json()

    def prepare_llm_call(self, session_id: str, message: str, agent_id: str = "default-agent",
                         provider: str = "openai", model: str = "gpt-4.1-mini",
                         optimization_mode: str = "medium", compare_with_raw: bool = True,
                         max_context_tokens: int = 16000, **kwargs: Any) -> dict:
        """Ask Context Fabric to compile context and return a provider-specific LLM call.

        The returned call should be executed by the client using client-owned keys.
        """
        return self.respond(
            session_id=session_id,
            message=message,
            agent_id=agent_id,
            provider=provider,
            model=model,
            optimization_mode=optimization_mode,
            compare_with_raw=compare_with_raw,
            max_context_tokens=max_context_tokens,
            llm_execution={"mode": "return_call"},
            **kwargs,
        )

    def complete_client_llm_call(self, client_model_call_id: str, *, session_id: str, agent_id: str,
                                 context_package_id: str, provider: str, model: str,
                                 response_text: str, usage: dict[str, Any] | None = None,
                                 optimization: dict[str, Any] | None = None,
                                 raw_provider_response: dict[str, Any] | None = None,
                                 metadata: dict[str, Any] | None = None) -> dict:
        payload = {
            "session_id": session_id,
            "agent_id": agent_id,
            "context_package_id": context_package_id,
            "provider": provider,
            "model": model,
            "response_text": response_text,
            "usage": usage or {},
            "optimization": optimization or {},
            "raw_provider_response": raw_provider_response or {},
            "metadata": metadata or {},
        }
        with httpx.Client(timeout=self.timeout) as client:
            resp = client.post(
                self.base_url.rstrip("/") + f"/client-llm-calls/{client_model_call_id}/complete",
                json=payload,
            )
            resp.raise_for_status()
            return resp.json()

    def compare(self, session_id: str, message: str, agent_id: str = "default-agent",
                modes: list[str] | None = None, max_context_tokens: int = 16000,
                provider: str = "mock", model: str = "mock-fast") -> dict:
        payload = {
            "session_id": session_id,
            "agent_id": agent_id,
            "message": message,
            "modes": modes or ["none", "conservative", "medium", "aggressive"],
            "max_context_tokens": max_context_tokens,
            "provider": provider,
            "model": model,
        }
        with httpx.Client(timeout=self.timeout) as client:
            resp = client.post(self.base_url.rstrip("/") + "/context/compare", json=payload)
            resp.raise_for_status()
            return resp.json()

    def dashboard(self) -> dict:
        with httpx.Client(timeout=self.timeout) as client:
            resp = client.get(self.base_url.rstrip("/") + "/metrics/dashboard")
            resp.raise_for_status()
            return resp.json()

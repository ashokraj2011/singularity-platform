# Context Fabric

Context Fabric is a standalone LLM context optimization platform. It sits between applications/agents and LLMs, keeps session context outside the model, summarizes long conversations, compiles optimized context packages, calls model providers through a gateway, and records raw-vs-optimized token savings.

## What is included

This MVP contains four independent FastAPI services:

1. **context-api-service** — public API for clients. Orchestrates memory, context compile, LLM calls, and metrics.
2. **llm-gateway-service** — model gateway for mock, OpenRouter/OpenAI-compatible, OpenAI-compatible custom endpoints, and Ollama.
3. **context-memory-service** — conversation storage, summaries, memories, and context compiler.
4. **metrics-ledger-service** — token-savings and cost-savings ledger.

It also includes a small Python SDK and smoke test.

## Quick start with Docker Compose

```bash
cp .env.example .env
# Optional: edit OPENROUTER_API_KEY or OLLAMA_BASE_URL in .env

docker compose up --build
```

Open docs:

- Context API: http://localhost:8000/docs
- LLM Gateway: http://localhost:8001/docs
- Context Memory: http://localhost:8002/docs
- Metrics Ledger: http://localhost:8003/docs

## First call using mock model

```bash
curl -s http://localhost:8000/chat/respond \
  -H 'Content-Type: application/json' \
  -d '{
    "session_id":"demo-session",
    "agent_id":"developer-agent",
    "message":"Design the first version of Context Fabric backend.",
    "provider":"mock",
    "model":"mock-fast",
    "context_policy":{"optimization_mode":"medium","compare_with_raw":true,"max_context_tokens":12000}
  }' | jq
```

Send multiple calls to the same `session_id`; summaries and optimized context become more useful as the session grows.

## OpenRouter example

Set `OPENROUTER_API_KEY` in `.env`, then call:

```bash
curl -s http://localhost:8000/chat/respond \
  -H 'Content-Type: application/json' \
  -d '{
    "session_id":"openrouter-demo",
    "agent_id":"architect-agent",
    "message":"Summarize our architecture decisions and continue the design.",
    "provider":"openrouter",
    "model":"openai/gpt-4o-mini",
    "context_policy":{"optimization_mode":"medium","compare_with_raw":true,"max_context_tokens":16000}
  }' | jq
```

## Ollama example

Start Ollama locally and expose it to Docker, or run the services directly on your machine. Then call:

```json
{
  "provider": "ollama",
  "model": "qwen2.5-coder:7b"
}
```

By default, `OLLAMA_BASE_URL=http://host.docker.internal:11434` in Docker Compose.

## Core API

### POST `/chat/respond`

This is the main product API.

It:

1. Saves the user message.
2. Optionally refreshes the rolling summary.
3. Builds raw context.
4. Builds optimized context.
5. Calls the LLM Gateway.
6. Saves assistant response.
7. Records token savings in the metrics ledger.
8. Returns response + savings receipt.

Example response:

```json
{
  "response": "...",
  "session_id": "demo-session",
  "context_package_id": "...",
  "model_call_id": "...",
  "optimization": {
    "mode": "medium",
    "raw_input_tokens": 52000,
    "optimized_input_tokens": 8400,
    "tokens_saved": 43600,
    "percent_saved": 83.84,
    "estimated_cost_saved": 0.21
  }
}
```

### POST `/context/compare`

Compares context modes without calling an LLM.

```bash
curl -s http://localhost:8000/context/compare \
  -H 'Content-Type: application/json' \
  -d '{
    "session_id":"demo-session",
    "agent_id":"developer-agent",
    "message":"Continue the implementation",
    "modes":["none","conservative","medium","aggressive"],
    "max_context_tokens":16000
  }' | jq
```

## Service ports

| Service | Port |
|---|---:|
| context-api-service | 8000 |
| llm-gateway-service | 8001 |
| context-memory-service | 8002 |
| metrics-ledger-service | 8003 |

## Local development without Docker

From repo root:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements-dev.txt

export PYTHONPATH=$PWD:$PWD/shared

uvicorn services.llm_gateway_service.app.main:app --port 8001 --reload
uvicorn services.context_memory_service.app.main:app --port 8002 --reload
uvicorn services.metrics_ledger_service.app.main:app --port 8003 --reload
uvicorn services.context_api_service.app.main:app --port 8000 --reload
```

## Design notes

- SQLite is used by default for easy local testing.
- Each service owns its own SQLite DB file under `./data`.
- The services are independent; later you can move each to PostgreSQL with minimal changes.
- Token counting uses `tiktoken` if available, otherwise a conservative approximation.
- Summarization uses the LLM Gateway if configured, but falls back to an extractive structured summary if the summarizer model is unavailable.

## Next upgrades

1. Replace SQLite with PostgreSQL schemas.
2. Add pgvector for semantic memory retrieval.
3. Add agent-wise context profiles and self-tuning policy learner.
4. Add quality evaluation and missing-context detection.
5. Add code-aware context slicing for developer agents.
6. Add signed receipts/hash-chain ledger.

## Provider extensions: Claude API and headless CLIs

### Direct Anthropic Claude API

Set these in `.env`:

```env
ANTHROPIC_API_KEY=your_anthropic_key
ANTHROPIC_BASE_URL=https://api.anthropic.com/v1
ANTHROPIC_VERSION=2023-06-01
```

Call it:

```bash
curl -s http://localhost:8000/chat/respond \
  -H 'Content-Type: application/json' \
  -d '{
    "session_id": "claude-api-demo",
    "agent_id": "architect-agent",
    "message": "Design the Context Fabric provider registry.",
    "provider": "anthropic",
    "model": "claude-3-5-sonnet-latest",
    "max_output_tokens": 1200,
    "context_policy": {
      "optimization_mode": "medium",
      "compare_with_raw": true,
      "max_context_tokens": 16000
    }
  }' | jq
```

### GitHub Copilot CLI provider

This provider runs GitHub Copilot CLI in non-interactive mode using `copilot -p "..." -s`.

Install/authenticate where `llm-gateway-service` runs:

```bash
npm install -g @github/copilot
copilot
# then login/trust the working directory as required by GitHub Copilot CLI
```

Configure `.env`:

```env
COPILOT_CLI_COMMAND=copilot
CLI_WORKDIR=/workspace
CLI_TIMEOUT_SECONDS=600
CONTEXT_FABRIC_WORKSPACE=/path/to/your/repo
```

Call it:

```bash
curl -s http://localhost:8000/chat/respond \
  -H 'Content-Type: application/json' \
  -d '{
    "session_id": "copilot-cli-demo",
    "agent_id": "developer-agent",
    "message": "Explain this repository structure and suggest the next backend improvement.",
    "provider": "copilot_cli",
    "model": "default",
    "context_policy": {
      "optimization_mode": "medium",
      "compare_with_raw": true,
      "max_context_tokens": 16000
    }
  }' | jq
```

### Claude Code CLI provider

This provider runs Claude Code in non-interactive mode using `claude -p "..."`.

Configure `.env`:

```env
CLAUDE_CODE_CLI_COMMAND=claude
CLI_WORKDIR=/workspace
CLI_TIMEOUT_SECONDS=600
CONTEXT_FABRIC_WORKSPACE=/path/to/your/repo
```

Call it:

```bash
curl -s http://localhost:8000/chat/respond \
  -H 'Content-Type: application/json' \
  -d '{
    "session_id": "claude-code-cli-demo",
    "agent_id": "developer-agent",
    "message": "Review the repo and propose a safe refactor plan.",
    "provider": "claude_code_cli",
    "model": "default",
    "context_policy": {
      "optimization_mode": "medium",
      "compare_with_raw": true,
      "max_context_tokens": 16000
    }
  }' | jq
```

### Important CLI provider notes

CLI providers are different from normal LLM API providers:

- They may read files, modify files, and run commands.
- They rely on local authentication and local organization policies.
- Token usage is estimated locally unless the CLI exposes exact usage.
- Cost is recorded as `0.0` by default; map it to your subscription or internal chargeback later.
- For safer execution, run CLI providers in a dedicated sandbox/workspace, not your whole home directory.

## LLM Call Handoff / BYOK Mode

Context Fabric can now compile optimized context and return the exact LLM call for the client to execute with client-owned keys instead of calling the LLM on the server.

See `docs/LLM_CALL_HANDOFF.md`.

Quick example:

```bash
curl -s http://localhost:8000/chat/respond \
  -H 'Content-Type: application/json' \
  -d '{
    "session_id":"handoff-demo-001",
    "agent_id":"developer-agent",
    "message":"Explain where token saving happens.",
    "provider":"openai",
    "model":"gpt-4.1-mini",
    "llm_execution":{"mode":"return_call"},
    "context_policy":{"optimization_mode":"medium","compare_with_raw":true}
  }' | jq
```

The response contains `prepared_call`, `client_model_call_id`, `context_package_id`, and `optimization`. The client executes `prepared_call` with its own key and posts the model response back to:

```text
POST /client-llm-calls/{client_model_call_id}/complete
```
